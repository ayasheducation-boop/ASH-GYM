export type GoalOption =
  | 'Weight Loss'
  | 'Weight Gain'
  | 'Strength Training'
  | 'Yoga & Mobility'
  | 'Athletic Conditioning'
  | 'General Fitness';

export type GenderOption = 'Male' | 'Female' | 'Non-binary' | 'Prefer not to say';

export type PageView = 'landing' | 'signup' | 'login' | 'dashboard';

export interface PaymentTransaction {
  id: string;
  monthLabel: string;
  amount: number;
  date: string;
  method: string;
  feeApproved: boolean;
}

export interface MemberProfile {
  id: string;
  fullName: string;
  username: string;
  email?: string;
  phone: string;
  address: string;
  age: number;
  heightInches: number;
  weightKg: number;
  gender: GenderOption;
  goal: GoalOption;
  password: string;
  profilePicture?: string;
  joinedAt: string;
  activeDays: number;
  inactiveDays: number;
  fitnessTypesDone: string[];
  membershipPlanName: string;
  membershipExpiresAt: string;
  transactions: PaymentTransaction[];
}

export interface HeroSlide {
  id: string;
  kicker: string;
  headline: string;
  subheadline: string;
  ctaLabel: string;
  image: string;
  imageAlt: string;
  fitMode?: 'cover' | 'contain';
  backdropColor?: string;
}

export interface ProgramItem {
  id: string;
  title: string;
  goalMapping: GoalOption;
  packagePrice: number;
  pricePeriod: string;
  sessionsPerWeek: string;
  duration: string;
  level: string;
  summary: string;
  highlights: string[];
  image: string;
  imageAlt: string;
}

export interface PricingPlan {
  id: string;
  name: string;
  tagline: string;
  monthlyPrice: number;
  annualPrice: number;
  featured?: boolean;
  ctaLabel: string;
  features: string[];
}

export interface TimetableSlot {
  id: string;
  timeRange: string;
  days: string;
  genderAccess: 'Male' | 'Female' | 'Both';
  sessionTitle: string;
  coach: string;
  zone: string;
}

export interface TestimonialItem {
  id: string;
  name: string;
  role: string;
  program: string;
  metric: string;
  timeframe: string;
  quote: string;
  image?: string;
  initials: string;
}

export interface SuccessPhotoStory {
  id: string;
  name: string;
  age: number;
  program: string;
  milestone: string;
  lifeStory: string;
  image: string;
  imageAlt: string;
}

export interface BlogPost {
  id: string;
  title: string;
  category: 'Nutrition' | 'Strength' | 'Mobility' | 'Recovery';
  readTime: string;
  publishedDate: string;
  author: string;
  excerpt: string;
  body: string[];
  image: string;
  imageAlt: string;
}

export interface FaqItem {
  id: string;
  question: string;
  answer: string;
}
