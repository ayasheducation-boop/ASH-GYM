import { AlertTriangle, CheckCircle2, Dumbbell, Info, Scale } from 'lucide-react';
import {
  calculateBMIFromFeetNotation,
  classifyBMI,
  formatInchesToFeetInches,
  inchesToCm,
  parseFeetNotationToInches,
} from '../utils/bmi';
import type { GoalOption } from '../types/gym';

interface BMIAssessmentCardProps {
  heightFeet: string;
  weightKg: number | string;
  currentGoal?: GoalOption | '';
  onApplySuggestedGoal?: (goal: GoalOption) => void;
}

export function BMIAssessmentCard({
  heightFeet,
  weightKg,
  currentGoal,
  onApplySuggestedGoal,
}: BMIAssessmentCardProps) {
  const numericWeight =
    typeof weightKg === 'string' ? Number(weightKg) : weightKg;

  const parsedInches = parseFeetNotationToInches(heightFeet);
  const bmi = calculateBMIFromFeetNotation(numericWeight, heightFeet);

  if (bmi === null || parsedInches === null) {
    return (
      <div
        data-testid="bmi-card-empty"
        className="bg-white border border-slate-200/90 rounded-2xl p-6 space-y-5"
      >
        <div className="flex items-center gap-2.5">
          <Scale className="w-5 h-5 text-red-600 shrink-0" aria-hidden="true" />
          <h3
            className="text-xl font-bold text-slate-950 tracking-tight"
            style={{ fontFamily: 'var(--font-display)' }}
          >
            Live BMI &amp; Goal Guide
          </h3>
        </div>
        <p className="text-sm text-slate-600 leading-relaxed">
          Enter your height in feet (e.g. 5.7 for 5 ft 7 in) and weight in kg to automatically calculate your BMI, see whether you fall in an underweight, healthy, overweight, or unhealthy range, and receive personalized workout suggestions.
        </p>
        <div className="grid grid-cols-2 gap-3 pt-3 border-t border-slate-100 text-xs text-slate-600 tabular-nums">
          <div className="py-1.5">
            <span className="font-semibold text-slate-900 block">Underweight</span>
            <span>Below 18.5</span>
          </div>
          <div className="py-1.5">
            <span className="font-semibold text-slate-900 block">Healthy Weight</span>
            <span>18.5 – 24.9</span>
          </div>
          <div className="py-1.5">
            <span className="font-semibold text-slate-900 block">Overweight</span>
            <span>25.0 – 29.9</span>
          </div>
          <div className="py-1.5">
            <span className="font-semibold text-slate-900 block">Unhealthy</span>
            <span>30.0 and above</span>
          </div>
        </div>
      </div>
    );
  }

  const heightCm = inchesToCm(parsedInches);
  const assessment = classifyBMI(bmi, heightCm);
  const feetLabel = formatInchesToFeetInches(parsedInches);

  const toneStyles = {
    info: {
      box: 'bg-sky-50 border-sky-200 text-sky-900',
      icon: <Info className="w-5 h-5 text-sky-700 shrink-0" aria-hidden="true" />,
      barColor: 'bg-sky-600',
    },
    healthy: {
      box: 'bg-emerald-50 border-emerald-200 text-emerald-900',
      icon: <CheckCircle2 className="w-5 h-5 text-emerald-700 shrink-0" aria-hidden="true" />,
      barColor: 'bg-emerald-600',
    },
    caution: {
      box: 'bg-amber-50 border-amber-200 text-amber-900',
      icon: <AlertTriangle className="w-5 h-5 text-amber-700 shrink-0" aria-hidden="true" />,
      barColor: 'bg-amber-600',
    },
    alert: {
      box: 'bg-red-50 border-red-200 text-red-900',
      icon: <AlertTriangle className="w-5 h-5 text-red-700 shrink-0" aria-hidden="true" />,
      barColor: 'bg-red-600',
    },
  }[assessment.statusTone];

  const meterPercent = Math.min(100, Math.max(0, ((bmi - 14) / (38 - 14)) * 100));

  return (
    <div
      data-testid="bmi-card-result"
      aria-live="polite"
      className="bg-white border border-slate-200/90 rounded-2xl p-6 space-y-5"
    >
      <div className="flex items-start justify-between gap-4">
        <div>
          <p className="text-xs font-semibold text-slate-500">
            Live BMI Calculation
          </p>
          <div className="flex items-baseline gap-2.5 mt-1">
            <span
              data-testid="bmi-value"
              className="text-4xl font-bold text-slate-950 tabular-nums tracking-tight"
              style={{ fontFamily: 'var(--font-display)' }}
            >
              {assessment.bmi.toFixed(1)}
            </span>
            <span className="text-sm font-semibold text-slate-700">
              kg/m²
            </span>
          </div>
        </div>

        <div
          data-testid="bmi-category"
          className={`inline-flex items-center gap-2 px-3 py-1.5 rounded-lg border text-xs font-semibold ${toneStyles.box}`}
        >
          {toneStyles.icon}
          <span>{assessment.category}</span>
        </div>
      </div>

      {/* Visual BMI Spectrum */}
      <div className="space-y-1.5">
        <div className="relative h-2.5 w-full rounded-full overflow-hidden flex bg-slate-100">
          <div className="w-[18.75%] bg-sky-300" title="Underweight (<18.5)" />
          <div className="w-[27.08%] bg-emerald-400" title="Healthy (18.5-24.9)" />
          <div className="w-[20.83%] bg-amber-300" title="Overweight (25-29.9)" />
          <div className="flex-1 bg-red-400" title="Unhealthy (>=30)" />
        </div>
        <div className="relative h-3 w-full">
          <div
            className="absolute top-0 -translate-x-1/2 flex flex-col items-center"
            style={{ left: `${meterPercent}%` }}
          >
            <span className={`w-2.5 h-2.5 rounded-full border-2 border-white shadow ${toneStyles.barColor}`} />
          </div>
        </div>
        <div className="flex justify-between text-[11px] text-slate-500 tabular-nums">
          <span>Underweight &lt;18.5</span>
          <span>Healthy 18.5–24.9</span>
          <span>Over 25–29.9</span>
          <span>30+</span>
        </div>
      </div>

      {/* Simple & Clean "Why" Section Separated by Hairline Dividers */}
      <div className="py-4 border-y border-slate-100 space-y-2">
        <p className="text-xs font-semibold text-slate-900">
          Why this reading matters
        </p>
        <p className="text-sm text-slate-700 leading-relaxed">
          {assessment.whyExplanation}
        </p>
        <p className="text-xs text-slate-600 pt-1 tabular-nums">
          Healthy weight range for {feetLabel} ({heightCm} cm):{' '}
          <span className="font-semibold text-slate-900">
            {assessment.healthyWeightRangeKg[0]} kg – {assessment.healthyWeightRangeKg[1]} kg
          </span>
        </p>
      </div>

      {/* Personalized Workout & Goal Suggestion */}
      <div className="space-y-3">
        <div className="flex items-center gap-2">
          <Dumbbell className="w-4 h-4 text-red-600 shrink-0" aria-hidden="true" />
          <p className="text-sm font-bold text-slate-950">
            Recommended Goal: {assessment.suggestedGoal}
          </p>
        </div>

        <p className="text-xs font-medium text-slate-600">
          {assessment.suggestedPlanTitle}
        </p>

        <ol className="space-y-2 text-xs text-slate-700">
          {assessment.personalizedWorkouts.map((step, index) => (
            <li key={step} className="flex items-start gap-2.5">
              <span className="font-semibold text-red-600 tabular-nums shrink-0">
                0{index + 1}.
              </span>
              <span>{step}</span>
            </li>
          ))}
        </ol>

        <p className="text-xs text-slate-600 pt-3 border-t border-slate-100">
          <span className="font-semibold text-slate-900">Nutrition cue: </span>
          {assessment.nutritionNote}
        </p>

        {onApplySuggestedGoal && (
          <button
            type="button"
            onClick={() => onApplySuggestedGoal(assessment.suggestedGoal)}
            disabled={currentGoal === assessment.suggestedGoal}
            className={`w-full py-2.5 px-4 text-xs sm:text-sm font-semibold rounded-xl transition-colors duration-150 ${
              currentGoal === assessment.suggestedGoal
                ? 'bg-emerald-50 text-emerald-800 border border-emerald-200 cursor-default'
                : 'bg-slate-950 hover:bg-slate-800 text-white cursor-pointer'
            }`}
          >
            {currentGoal === assessment.suggestedGoal
              ? `Goal Set to ${assessment.suggestedGoal}`
              : `Apply Suggested Goal (${assessment.suggestedGoal})`}
          </button>
        )}
      </div>
    </div>
  );
}
