import { useState } from 'react';
import { ChevronDown } from 'lucide-react';
import { FAQ_ITEMS } from '../data/gymData';

export function FaqSection() {
  const [openId, setOpenId] = useState<string>('');

  const toggleItem = (id: string) => {
    setOpenId((prev) => (prev === id ? '' : id));
  };

  return (
    <section
      id="faq"
      className="w-full bg-slate-50/60 border-t border-slate-200/80 py-12 sm:py-16 md:py-20"
    >
      <div className="max-w-[1280px] mx-auto px-3 sm:px-6 lg:px-8">
        <div className="max-w-2xl mb-7 sm:mb-10 space-y-2.5">
          <p className="text-xs sm:text-sm font-semibold text-red-600">
            Frequently Asked Questions
          </p>
          <h2
            className="text-2xl sm:text-4xl font-bold tracking-tight text-slate-950 text-balance"
            style={{ fontFamily: 'var(--font-display)' }}
          >
            Answers Before Your First Session
          </h2>
          <p className="text-slate-600 text-sm sm:text-base leading-relaxed">
            Clear details on beginner onboarding, BMI goal suggestions, studio hours, and membership flexibility.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-3 sm:gap-4 items-start">
          {FAQ_ITEMS.map((item) => {
            const isOpen = openId === item.id;
            return (
              <div
                key={item.id}
                data-testid="faq-card"
                className={`bg-white border rounded-2xl transition-colors duration-150 ${
                  isOpen ? 'border-slate-300 shadow-xs' : 'border-slate-200/90 hover:border-slate-300'
                }`}
              >
                <button
                  type="button"
                  onClick={() => toggleItem(item.id)}
                  aria-expanded={isOpen}
                  aria-controls={`faq-panel-${item.id}`}
                  className="w-full py-3.5 px-4 sm:px-5 flex items-center justify-between gap-3 text-left cursor-pointer focus-visible:outline-2 focus-visible:outline-red-600 rounded-2xl"
                >
                  <span className="text-sm font-semibold text-slate-950 leading-snug">
                    {item.question}
                  </span>
                  <ChevronDown
                    className={`w-4 h-4 text-slate-500 shrink-0 transition-transform duration-150 ${
                      isOpen ? 'rotate-180 text-slate-950' : ''
                    }`}
                    aria-hidden="true"
                  />
                </button>
                {isOpen && (
                  <div
                    id={`faq-panel-${item.id}`}
                    className="pb-4 px-4 sm:px-5 pt-2.5 text-xs sm:text-sm text-slate-600 leading-relaxed border-t border-slate-100"
                  >
                    {item.answer}
                  </div>
                )}
              </div>
            );
          })}
        </div>
      </div>
    </section>
  );
}
