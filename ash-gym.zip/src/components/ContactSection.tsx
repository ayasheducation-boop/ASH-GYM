import { useState, type FormEvent } from 'react';
import { Check, Clock, Mail, MapPin, Phone } from 'lucide-react';
import { validateContactForm, type ContactFormValues, type ValidationErrors } from '../utils/bmi';

export function ContactSection() {
  const [values, setValues] = useState<ContactFormValues>({
    name: '',
    contact: '',
    topic: 'Personal Coaching Inquiry',
    message: '',
  });
  const [errors, setErrors] = useState<ValidationErrors<keyof ContactFormValues>>({});
  const [submitted, setSubmitted] = useState(false);

  const handleSubmit = (e: FormEvent) => {
    e.preventDefault();
    const validationErrors = validateContactForm(values);
    setErrors(validationErrors);
    if (Object.keys(validationErrors).length === 0) {
      setSubmitted(true);
    }
  };

  return (
    <section
      id="contact"
      className="w-full bg-white border-t border-slate-200/80 py-14 sm:py-16 md:py-24"
    >
      <div className="max-w-[1280px] mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-10 lg:gap-12 items-start">
          {/* Studio Contact Info */}
          <div className="lg:col-span-5 space-y-6">
            <div className="space-y-3">
              <p className="text-xs sm:text-sm font-semibold text-red-600">
                Get In Touch
              </p>
              <h2
                className="text-2xl sm:text-4xl font-bold tracking-tight text-slate-950 text-balance"
                style={{ fontFamily: 'var(--font-display)' }}
              >
                Visit the Studio or Message Coach Ash
              </h2>
              <p className="text-slate-600 text-sm sm:text-base leading-relaxed">
                Have a question about injury-safe lifting, prenatal yoga, or scheduling a studio tour? Send a quick message and our coaching desk replies the same day.
              </p>
            </div>

            <div className="space-y-4 pt-2 text-sm text-slate-700">
              <div className="flex items-start gap-3">
                <MapPin className="w-5 h-5 text-red-600 shrink-0 mt-0.5" aria-hidden="true" />
                <div>
                  <p className="font-semibold text-slate-950">ASH GYM Training Studio</p>
                  <p className="text-slate-600">428 Mercer Street, West District</p>
                </div>
              </div>

              <div className="flex items-start gap-3">
                <Clock className="w-5 h-5 text-red-600 shrink-0 mt-0.5" aria-hidden="true" />
                <div>
                  <p className="font-semibold text-slate-950">Studio Hours</p>
                  <p className="text-slate-600 tabular-nums">
                    Mon–Sat: 6:00 AM – 10:00 PM · Sun: 7:30 AM – 4:00 PM
                  </p>
                </div>
              </div>

              <div className="flex items-start gap-3">
                <Phone className="w-5 h-5 text-red-600 shrink-0 mt-0.5" aria-hidden="true" />
                <div>
                  <p className="font-semibold text-slate-950">Coaching Desk</p>
                  <p className="text-slate-600 tabular-nums">+1 (555) 390-8420</p>
                </div>
              </div>

              <div className="flex items-start gap-3">
                <Mail className="w-5 h-5 text-red-600 shrink-0 mt-0.5" aria-hidden="true" />
                <div>
                  <p className="font-semibold text-slate-950">Email</p>
                  <p className="text-slate-600">hello@ashgym.studio</p>
                </div>
              </div>
            </div>
          </div>

          {/* Contact Form */}
          <div className="lg:col-span-7 bg-white border border-slate-200/90 rounded-2xl p-6 sm:p-8 shadow-xs">
            {submitted ? (
              <div className="py-8 text-center space-y-4">
                <div className="w-12 h-12 rounded-full bg-emerald-50 border border-emerald-200 text-emerald-700 inline-flex items-center justify-center mx-auto">
                  <Check className="w-6 h-6" aria-hidden="true" />
                </div>
                <h3
                  className="text-2xl font-bold text-slate-950"
                  style={{ fontFamily: 'var(--font-display)' }}
                >
                  Message Received
                </h3>
                <p className="text-sm text-slate-600 max-w-md mx-auto">
                  Thank you, {values.name}. Coach Ash’s desk has logged your inquiry regarding{' '}
                  <span className="font-medium text-slate-900">{values.topic}</span> and will reach out to{' '}
                  <span className="font-medium text-slate-900">{values.contact}</span> shortly.
                </p>
                <button
                  type="button"
                  onClick={() => {
                    setSubmitted(false);
                    setValues({
                      name: '',
                      contact: '',
                      topic: 'Personal Coaching Inquiry',
                      message: '',
                    });
                  }}
                  className="px-4 py-2 text-sm font-semibold text-slate-800 border border-slate-300 rounded-lg hover:bg-slate-50 cursor-pointer"
                >
                  Send Another Inquiry
                </button>
              </div>
            ) : (
              <form onSubmit={handleSubmit} noValidate className="space-y-5">
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  <div>
                    <label
                      htmlFor="contact-name"
                      className="block text-sm font-medium text-slate-800 mb-1.5"
                    >
                      Your Name
                    </label>
                    <input
                      id="contact-name"
                      type="text"
                      value={values.name}
                      onChange={(e) =>
                        setValues((prev) => ({ ...prev, name: e.target.value }))
                      }
                      placeholder="Jordan Taylor"
                      className="w-full px-3.5 py-2.5 text-sm text-slate-900 bg-white border border-slate-300 rounded-lg focus:outline-none focus:border-slate-900"
                    />
                    {errors.name && (
                      <p className="mt-1 text-xs text-red-600">{errors.name}</p>
                    )}
                  </div>

                  <div>
                    <label
                      htmlFor="contact-info"
                      className="block text-sm font-medium text-slate-800 mb-1.5"
                    >
                      Phone Number or Email
                    </label>
                    <input
                      id="contact-info"
                      type="text"
                      value={values.contact}
                      onChange={(e) =>
                        setValues((prev) => ({ ...prev, contact: e.target.value }))
                      }
                      placeholder="+1 555 234 5678 or email"
                      className="w-full px-3.5 py-2.5 text-sm text-slate-900 bg-white border border-slate-300 rounded-lg focus:outline-none focus:border-slate-900"
                    />
                    {errors.contact && (
                      <p className="mt-1 text-xs text-red-600">{errors.contact}</p>
                    )}
                  </div>
                </div>

                <div>
                  <label
                    htmlFor="contact-topic"
                    className="block text-sm font-medium text-slate-800 mb-1.5"
                  >
                    Training Topic
                  </label>
                  <select
                    id="contact-topic"
                    value={values.topic}
                    onChange={(e) =>
                      setValues((prev) => ({ ...prev, topic: e.target.value }))
                    }
                    className="w-full px-3.5 py-2.5 text-sm text-slate-900 bg-white border border-slate-300 rounded-lg focus:outline-none focus:border-slate-900"
                  >
                    <option value="Personal Coaching Inquiry">Personal Coaching Inquiry</option>
                    <option value="Weight Gain Program">Weight Gain Program</option>
                    <option value="Weight Loss Program">Weight Loss Program</option>
                    <option value="Strength Training">Strength Training</option>
                    <option value="Yoga & Mobility Classes">Yoga &amp; Mobility Classes</option>
                    <option value="14-Day Trial Pass">14-Day Trial Pass</option>
                  </select>
                </div>

                <div>
                  <label
                    htmlFor="contact-message"
                    className="block text-sm font-medium text-slate-800 mb-1.5"
                  >
                    How Can We Help?
                  </label>
                  <textarea
                    id="contact-message"
                    rows={4}
                    value={values.message}
                    onChange={(e) =>
                      setValues((prev) => ({ ...prev, message: e.target.value }))
                    }
                    placeholder="Share your training goal, preferred workout time, or any questions..."
                    className="w-full px-3.5 py-2.5 text-sm text-slate-900 bg-white border border-slate-300 rounded-lg focus:outline-none focus:border-slate-900"
                  />
                  {errors.message && (
                    <p className="mt-1 text-xs text-red-600">{errors.message}</p>
                  )}
                </div>

                <button
                  type="submit"
                  className="w-full sm:w-auto px-6 py-3 text-sm font-semibold text-white bg-slate-900 hover:bg-slate-800 rounded-lg transition-colors duration-150 cursor-pointer"
                >
                  Send Message
                </button>
              </form>
            )}
          </div>
        </div>
      </div>
    </section>
  );
}
