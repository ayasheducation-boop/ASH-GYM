import { useState, type FormEvent } from 'react';
import { ArrowLeft } from 'lucide-react';
import type { MemberProfile, PageView } from '../types/gym';

interface LoginPageProps {
  members: MemberProfile[];
  onLoginSuccess: (member: MemberProfile) => void;
  onNavigate: (view: PageView) => void;
}

export function LoginPage({
  members,
  onLoginSuccess,
  onNavigate,
}: LoginPageProps) {
  const [identifier, setIdentifier] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState('');

  const handleSubmit = (e: FormEvent) => {
    e.preventDefault();
    setError('');

    const cleanId = identifier.trim().toLowerCase();
    if (!cleanId || !password) {
      setError('Enter both your username (or phone number) and password.');
      return;
    }

    const match = members.find(
      (m) =>
        m.username.toLowerCase() === cleanId ||
        m.phone.replace(/\D/g, '') === cleanId.replace(/\D/g, '')
    );

    if (!match || match.password !== password) {
      setError('Invalid credentials. Check your username/phone and password.');
      return;
    }

    onLoginSuccess(match);
  };

  const fillDemoAccount = () => {
    setIdentifier('alex_runner');
    setPassword('ashgym123');
    setError('');
  };

  return (
    <main className="w-full bg-slate-50/70 min-h-[calc(100vh-4rem)] py-12 sm:py-16">
      <div className="max-w-md mx-auto px-4 sm:px-6">
        <button
          type="button"
          onClick={() => onNavigate('landing')}
          className="inline-flex items-center gap-1.5 text-sm font-medium text-slate-600 hover:text-slate-950 mb-4 cursor-pointer"
        >
          <ArrowLeft className="w-4 h-4" aria-hidden="true" />
          <span>Back to Home</span>
        </button>

        <div className="bg-white border border-slate-200/90 rounded-2xl p-6 sm:p-8 space-y-6 shadow-xs">
          <div className="space-y-1.5">
            <h1
              className="text-2xl sm:text-3xl font-bold tracking-tight text-slate-950"
              style={{ fontFamily: 'var(--font-display)' }}
            >
              Member Login
            </h1>
            <p className="text-sm text-slate-600">
              Access your BMI tracker, profile, and personalized ASH GYM workout split.
            </p>
          </div>

          {error && (
            <div
              role="alert"
              className="p-3 rounded-lg bg-red-50 border border-red-200 text-xs font-medium text-red-800"
            >
              {error}
            </div>
          )}

          <form onSubmit={handleSubmit} noValidate className="space-y-4">
            <div>
              <label
                htmlFor="login-identifier"
                className="block text-sm font-medium text-slate-800 mb-1.5"
              >
                Username or Phone Number
              </label>
              <input
                id="login-identifier"
                type="text"
                value={identifier}
                onChange={(e) => setIdentifier(e.target.value)}
                placeholder="alex_runner"
                className="w-full px-3.5 py-2.5 text-sm text-slate-900 bg-white border border-slate-300 rounded-lg focus:outline-none focus:border-slate-900"
              />
            </div>

            <div>
              <label
                htmlFor="login-password"
                className="block text-sm font-medium text-slate-800 mb-1.5"
              >
                Password
              </label>
              <input
                id="login-password"
                type="password"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                placeholder="Enter your password"
                className="w-full px-3.5 py-2.5 text-sm text-slate-900 bg-white border border-slate-300 rounded-lg focus:outline-none focus:border-slate-900"
              />
            </div>

            <button
              type="submit"
              className="w-full py-3 px-5 text-sm font-semibold text-white bg-red-600 hover:bg-red-700 rounded-lg transition-colors duration-150 cursor-pointer"
            >
              Log In
            </button>
          </form>

          <div className="p-3.5 rounded-lg bg-slate-50 border border-slate-200 flex items-center justify-between gap-3">
            <div className="text-xs text-slate-600">
              <p className="font-semibold text-slate-900">Sample Member</p>
              <p className="tabular-nums">alex_runner · ashgym123</p>
            </div>
            <button
              type="button"
              onClick={fillDemoAccount}
              className="px-3 py-1.5 text-xs font-semibold text-slate-800 bg-white border border-slate-300 hover:bg-slate-100 rounded-md cursor-pointer whitespace-nowrap"
            >
              Use Sample
            </button>
          </div>

          <p className="text-center text-sm text-slate-600">
            New to ASH GYM?{' '}
            <button
              type="button"
              onClick={() => onNavigate('signup')}
              className="font-semibold text-red-600 hover:text-red-700 underline underline-offset-4 cursor-pointer"
            >
              Sign up now
            </button>
          </p>
        </div>
      </div>
    </main>
  );
}
