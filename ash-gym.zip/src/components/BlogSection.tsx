import { useState } from 'react';
import { ArrowRight, BookOpen, X } from 'lucide-react';
import { BLOG_POSTS } from '../data/gymData';
import type { BlogPost } from '../types/gym';

type BlogFilter = 'All' | BlogPost['category'];

const FILTER_OPTIONS: BlogFilter[] = [
  'All',
  'Nutrition',
  'Strength',
  'Mobility',
  'Recovery',
];

export function BlogSection() {
  const [selectedCategory, setSelectedCategory] = useState<BlogFilter>('All');
  const [activePost, setActivePost] = useState<BlogPost | null>(null);
  const [failedImages, setFailedImages] = useState<Record<string, boolean>>({});

  const visiblePosts =
    selectedCategory === 'All'
      ? BLOG_POSTS
      : BLOG_POSTS.filter((post) => post.category === selectedCategory);

  return (
    <section
      id="blog"
      className="w-full bg-white border-t border-slate-200/80 py-12 sm:py-16 md:py-24"
    >
      <div className="max-w-[1280px] mx-auto px-3 sm:px-6 lg:px-8">
        <div className="flex flex-col md:flex-row md:items-end justify-between gap-4 sm:gap-6 mb-8 sm:mb-12">
          <div className="max-w-xl space-y-2.5">
            <p className="text-xs sm:text-sm font-semibold text-red-600">
              Training &amp; Nutrition Journal
            </p>
            <h2
              className="text-2xl sm:text-4xl font-bold tracking-tight text-slate-950 text-balance"
              style={{ fontFamily: 'var(--font-display)' }}
            >
              Practical Guides From Coach Ash
            </h2>
            <p className="text-slate-600 text-sm sm:text-base leading-relaxed">
              Evidence-based notes on protein habits, barbell progression, and joint-friendly conditioning.
            </p>
          </div>

          <div
            role="tablist"
            aria-label="Filter articles by category"
            className="inline-flex flex-wrap items-center gap-1 p-1 bg-slate-100/80 border border-slate-200/80 rounded-xl self-start"
          >
            {FILTER_OPTIONS.map((category) => (
              <button
                key={category}
                type="button"
                role="tab"
                aria-selected={selectedCategory === category}
                onClick={() => setSelectedCategory(category)}
                className={`px-2.5 sm:px-3.5 py-1.5 text-xs sm:text-sm font-medium rounded-lg transition-colors duration-150 whitespace-nowrap shrink-0 cursor-pointer ${
                  selectedCategory === category
                    ? 'bg-white text-slate-950 shadow-xs'
                    : 'text-slate-600 hover:text-slate-950'
                }`}
              >
                {category}
              </button>
            ))}
          </div>
        </div>

        <div className="grid grid-cols-2 lg:grid-cols-4 gap-3 sm:gap-6">
          {visiblePosts.map((post) => (
            <article
              key={post.id}
              data-testid="blog-card"
              className="flex flex-col bg-white border border-slate-200/90 rounded-2xl overflow-hidden hover:border-slate-300 hover:shadow-sm transition-all duration-200"
            >
              <div className="aspect-[4/3] w-full bg-slate-100 overflow-hidden">
                {!failedImages[post.id] ? (
                  <img
                    src={post.image}
                    alt={post.imageAlt}
                    referrerPolicy="no-referrer"
                    onError={() =>
                      setFailedImages((prev) => ({ ...prev, [post.id]: true }))
                    }
                    className="w-full h-full object-cover"
                  />
                ) : (
                  <div className="w-full h-full flex items-center justify-center bg-slate-100 text-slate-400">
                    <BookOpen className="w-8 h-8" aria-hidden="true" />
                  </div>
                )}
              </div>

              <div className="flex-1 p-3.5 sm:p-5 flex flex-col">
                <div className="flex flex-wrap items-center gap-1.5 text-[11px] sm:text-xs text-slate-500 mb-2">
                  <span className="font-semibold text-red-600">
                    {post.category}
                  </span>
                  <span aria-hidden="true">·</span>
                  <span>{post.readTime}</span>
                </div>

                <h3 className="text-xs sm:text-base font-bold text-slate-950 leading-snug mb-1.5 sm:mb-2 line-clamp-2 sm:line-clamp-none">
                  {post.title}
                </h3>

                <p className="text-xs sm:text-sm text-slate-600 leading-relaxed mb-3.5 sm:mb-4 flex-1 line-clamp-2 sm:line-clamp-none">
                  {post.excerpt}
                </p>

                <div className="pt-2.5 sm:pt-3 border-t border-slate-100 flex items-center justify-between gap-2">
                  <span className="hidden sm:inline text-xs text-slate-500">
                    {post.publishedDate}
                  </span>
                  <button
                    type="button"
                    onClick={() => setActivePost(post)}
                    className="inline-flex items-center gap-1 text-xs font-semibold text-slate-950 hover:text-red-600 cursor-pointer whitespace-nowrap transition-colors"
                  >
                    <span>Read Article</span>
                    <ArrowRight className="w-3.5 h-3.5" aria-hidden="true" />
                  </button>
                </div>
              </div>
            </article>
          ))}
        </div>
      </div>

      {/* Accessible Article Reader Modal */}
      {activePost && (
        <div
          role="dialog"
          aria-modal="true"
          aria-labelledby="article-modal-title"
          className="fixed inset-0 z-50 bg-slate-950/50 backdrop-blur-xs flex items-center justify-center p-4"
          onClick={() => setActivePost(null)}
        >
          <div
            className="bg-white border border-slate-200 rounded-2xl max-w-2xl w-full max-h-[85vh] overflow-y-auto p-6 sm:p-8 shadow-xl"
            onClick={(e) => e.stopPropagation()}
          >
            <div className="flex items-start justify-between gap-4 mb-4">
              <div className="text-xs text-slate-500 flex items-center gap-2">
                <span className="font-semibold text-red-600">
                  {activePost.category}
                </span>
                <span aria-hidden="true">·</span>
                <span>{activePost.readTime}</span>
                <span aria-hidden="true">·</span>
                <span>{activePost.publishedDate}</span>
              </div>
              <button
                type="button"
                onClick={() => setActivePost(null)}
                aria-label="Close article"
                className="w-9 h-9 inline-flex items-center justify-center rounded-xl border border-slate-200 text-slate-700 hover:bg-slate-50 cursor-pointer shrink-0"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <h3
              id="article-modal-title"
              className="text-2xl sm:text-3xl font-bold text-slate-950 mb-2 leading-tight tracking-tight"
              style={{ fontFamily: 'var(--font-display)' }}
            >
              {activePost.title}
            </h3>
            <p className="text-xs text-slate-500 mb-5">By {activePost.author}</p>

            <div className="aspect-[16/9] w-full rounded-xl overflow-hidden bg-slate-100 mb-6">
              <img
                src={activePost.image}
                alt={activePost.imageAlt}
                referrerPolicy="no-referrer"
                className="w-full h-full object-cover"
              />
            </div>

            <div className="space-y-4 text-slate-700 text-base leading-relaxed">
              {activePost.body.map((paragraph, index) => (
                <p key={index}>{paragraph}</p>
              ))}
            </div>
          </div>
        </div>
      )}
    </section>
  );
}
