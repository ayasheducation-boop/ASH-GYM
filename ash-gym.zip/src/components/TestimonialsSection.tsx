import { useState } from 'react';
import { TESTIMONIALS } from '../data/gymData';

export function TestimonialsSection() {
  const [failedPortraits, setFailedPortraits] = useState<Record<string, boolean>>({});

  return (
    <section
      id="testimonials"
      className="w-full bg-white py-12 sm:py-16 md:py-24 border-t border-slate-200/80"
    >
      <div className="max-w-[1280px] mx-auto px-3 sm:px-6 lg:px-8">
        <div className="max-w-2xl mb-8 sm:mb-12 space-y-2.5">
          <p className="text-xs sm:text-sm font-semibold text-red-600">
            Member Progress Stories
          </p>
          <h2
            className="text-2xl sm:text-4xl font-bold tracking-tight text-slate-950 text-balance"
            style={{ fontFamily: 'var(--font-display)' }}
          >
            Consistent Training, Documented Results
          </h2>
          <p className="text-slate-600 text-sm sm:text-base leading-relaxed">
            Real outcomes from studio members following structured strength, fat loss, weight gain, and yoga schedules.
          </p>
        </div>

        <div className="grid grid-cols-2 md:grid-cols-3 gap-3 sm:gap-6">
          {TESTIMONIALS.map((story) => (
            <article
              key={story.id}
              data-testid="testimonial-card"
              className="flex flex-col justify-between bg-white border border-slate-200/90 rounded-2xl p-4 sm:p-6 hover:border-slate-300 transition-colors duration-150"
            >
              <div>
                <div className="pb-3 sm:pb-4 mb-3 sm:mb-4 border-b border-slate-100">
                  <p
                    className="text-base sm:text-xl font-bold text-slate-950 tabular-nums leading-tight"
                    style={{ fontFamily: 'var(--font-display)' }}
                  >
                    {story.metric}
                  </p>
                  <p className="text-[11px] sm:text-xs text-slate-500 mt-1 tabular-nums">
                    {story.timeframe}
                  </p>
                </div>

                <blockquote className="text-xs sm:text-sm text-slate-700 leading-relaxed line-clamp-4 sm:line-clamp-none mb-4 sm:mb-6">
                  “{story.quote}”
                </blockquote>
              </div>

              <div className="flex items-center gap-2.5 sm:gap-3.5 pt-3 border-t border-slate-100">
                {story.image && !failedPortraits[story.id] ? (
                  <img
                    src={story.image}
                    alt={`Portrait of ${story.name}`}
                    referrerPolicy="no-referrer"
                    onError={() =>
                      setFailedPortraits((prev) => ({ ...prev, [story.id]: true }))
                    }
                    className="w-9 h-9 sm:w-11 sm:h-11 rounded-full object-cover border border-slate-200 shrink-0"
                  />
                ) : (
                  <div
                    aria-hidden="true"
                    className="w-9 h-9 sm:w-11 sm:h-11 rounded-full bg-slate-100 border border-slate-200 flex items-center justify-center text-xs sm:text-sm font-bold text-slate-700 shrink-0"
                  >
                    {story.initials}
                  </div>
                )}

                <div className="min-w-0">
                  <h3 className="text-xs sm:text-sm font-semibold text-slate-950 truncate">
                    {story.name}
                  </h3>
                  <p className="text-[11px] sm:text-xs text-slate-500 truncate">
                    {story.program}
                  </p>
                </div>
              </div>
            </article>
          ))}
        </div>
      </div>
    </section>
  );
}
