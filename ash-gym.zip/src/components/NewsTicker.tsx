import { Calendar, Clock, Dumbbell, HeartPulse } from 'lucide-react';
import { TICKER_ANNOUNCEMENTS, type TickerAnnouncement } from '../data/gymData';

function TickerIcon({ type }: { type: TickerAnnouncement['iconType'] }) {
  switch (type) {
    case 'clock':
      return <Clock className="w-3.5 h-3.5 text-red-600 shrink-0" aria-hidden="true" />;
    case 'calendar':
      return <Calendar className="w-3.5 h-3.5 text-red-600 shrink-0" aria-hidden="true" />;
    case 'dumbbell':
      return <Dumbbell className="w-3.5 h-3.5 text-red-600 shrink-0" aria-hidden="true" />;
    case 'heart':
      return <HeartPulse className="w-3.5 h-3.5 text-red-600 shrink-0" aria-hidden="true" />;
  }
}

export function NewsTicker() {
  const repeatedItems = [...TICKER_ANNOUNCEMENTS, ...TICKER_ANNOUNCEMENTS];

  return (
    <section
      aria-label="Studio schedule and announcements"
      className="w-full border-y border-slate-200/80 bg-white overflow-hidden"
    >
      <div className="w-full flex items-center h-10 sm:h-11">
        <div className="shrink-0 h-full bg-slate-950 text-white px-3 sm:px-4 text-xs font-semibold tracking-wide flex items-center gap-1.5 z-10 border-r border-slate-200">
          <Clock className="w-3.5 h-3.5 text-red-400 shrink-0" aria-hidden="true" />
          <span className="whitespace-nowrap sm:hidden">Updates</span>
          <span className="whitespace-nowrap hidden sm:inline">Studio Updates</span>
        </div>

        <div className="ticker-wrapper min-w-0 flex-1 overflow-hidden">
          <div data-testid="ticker-track" className="ticker-track items-center">
            {repeatedItems.map((item, idx) => (
              <div
                key={`${item.id}-${idx}`}
                className="inline-flex items-center gap-2 px-4 sm:px-6 text-xs sm:text-sm text-slate-700 whitespace-nowrap shrink-0"
              >
                <TickerIcon type={item.iconType} />
                <span className="font-semibold text-slate-900 tabular-nums">
                  {item.timeOrDay}
                </span>
                <span aria-hidden="true" className="text-slate-400">
                  ·
                </span>
                <span>{item.text}</span>
              </div>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
}
