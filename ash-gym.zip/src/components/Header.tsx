import { useState } from 'react';
import { Menu, X } from 'lucide-react';
import type { MemberProfile, PageView } from '../types/gym';

interface HeaderProps {
  currentView: PageView;
  activeMember: MemberProfile | null;
  onNavigate: (view: PageView, sectionId?: string) => void;
  onLogout: () => void;
}

const NAV_LINKS = [
  { label: 'Programs', sectionId: 'programs' },
  { label: 'Timetable', sectionId: 'timetable' },
  { label: 'Pricing', sectionId: 'pricing' },
  { label: 'Stories', sectionId: 'testimonials' },
  { label: 'Blog', sectionId: 'blog' },
];

export function Header({
  currentView,
  activeMember,
  onNavigate,
  onLogout,
}: HeaderProps) {
  const [mobileOpen, setMobileOpen] = useState(false);

  const handleLinkClick = (sectionId: string) => {
    setMobileOpen(false);
    onNavigate('landing', sectionId);
  };

  return (
    <header className="sticky top-0 z-40 w-full bg-white/95 backdrop-blur-md border-b border-slate-200/80">
      <div className="max-w-[1280px] mx-auto px-4 sm:px-6 lg:px-8 h-16 flex items-center justify-between gap-8">
        {/* Zone 1: Brand Wordmark */}
        <a
          href="#top"
          onClick={(e) => {
            e.preventDefault();
            setMobileOpen(false);
            onNavigate('landing', 'top');
          }}
          className="inline-flex items-center gap-2.5 text-slate-950 whitespace-nowrap shrink-0 focus-visible:outline-2 focus-visible:outline-offset-4 focus-visible:outline-red-600 rounded"
        >
          <img
            src="/src/assets/images/ash_gym_logo.png"
            alt="ASH GYM emblem"
            className="h-9 sm:h-10 w-auto object-contain shrink-0"
          />
          <span
            className="text-xl sm:text-2xl font-bold tracking-tight uppercase"
            style={{ fontFamily: 'var(--font-display)' }}
          >
            ASH GYM
          </span>
        </a>

        {/* Zone 2: Concise Single-Line Navigation Links */}
        <nav
          aria-label="Primary navigation"
          className="hidden md:flex items-center gap-7 text-sm font-medium text-slate-600"
        >
          {NAV_LINKS.map((link) => (
            <a
              key={link.sectionId}
              href={`#${link.sectionId}`}
              onClick={(e) => {
                e.preventDefault();
                handleLinkClick(link.sectionId);
              }}
              className="py-1 text-slate-700 hover:text-slate-950 border-b-2 border-transparent hover:border-red-600 transition-colors duration-150 whitespace-nowrap shrink-0 focus-visible:outline-2 focus-visible:outline-offset-4 focus-visible:outline-red-600"
            >
              {link.label}
            </a>
          ))}
        </nav>

        {/* Zone 3: Login & Signup Action Zone */}
        <div className="hidden md:flex items-center gap-3 shrink-0">
          {activeMember ? (
            <>
              <button
                type="button"
                onClick={() => onNavigate('dashboard')}
                className={`px-4 py-2 text-sm font-medium rounded-lg border transition-colors duration-150 whitespace-nowrap shrink-0 cursor-pointer ${
                  currentView === 'dashboard'
                    ? 'bg-slate-900 text-white border-slate-900'
                    : 'bg-white text-slate-800 border-slate-300 hover:bg-slate-50'
                }`}
              >
                My Plan ({activeMember.username})
              </button>
              <button
                type="button"
                onClick={onLogout}
                className="px-4 py-2 text-sm font-medium text-slate-700 hover:text-slate-950 rounded-lg hover:bg-slate-100 transition-colors duration-150 whitespace-nowrap shrink-0 cursor-pointer"
              >
                Sign Out
              </button>
            </>
          ) : (
            <>
              <button
                type="button"
                onClick={() => onNavigate('login')}
                className={`px-4 py-2 text-sm font-medium rounded-lg border transition-colors duration-150 whitespace-nowrap shrink-0 cursor-pointer ${
                  currentView === 'login'
                    ? 'border-slate-900 bg-slate-100 text-slate-950'
                    : 'border-slate-300 bg-white text-slate-800 hover:bg-slate-50'
                }`}
              >
                Login
              </button>
              <button
                type="button"
                onClick={() => onNavigate('signup')}
                className="px-5 py-2 text-sm font-semibold text-white bg-red-600 hover:bg-red-700 rounded-lg transition-colors duration-150 whitespace-nowrap shrink-0 cursor-pointer focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-red-600"
              >
                Sign Up
              </button>
            </>
          )}
        </div>

        {/* Mobile Menu Button */}
        <button
          type="button"
          onClick={() => setMobileOpen((prev) => !prev)}
          aria-expanded={mobileOpen}
          aria-controls="mobile-nav-drawer"
          aria-label={mobileOpen ? 'Close navigation menu' : 'Open navigation menu'}
          className="md:hidden inline-flex items-center justify-center w-11 h-11 rounded-lg border border-slate-200 text-slate-800 hover:bg-slate-50 cursor-pointer"
        >
          {mobileOpen ? <X className="w-5 h-5" /> : <Menu className="w-5 h-5" />}
        </button>
      </div>

      {/* Mobile Navigation Drawer */}
      {mobileOpen && (
        <div
          id="mobile-nav-drawer"
          className="md:hidden border-t border-slate-200 bg-white px-4 py-4 space-y-3"
        >
          <nav aria-label="Mobile navigation" className="flex flex-col space-y-1">
            {NAV_LINKS.map((link) => (
              <a
                key={link.sectionId}
                href={`#${link.sectionId}`}
                onClick={(e) => {
                  e.preventDefault();
                  handleLinkClick(link.sectionId);
                }}
                className="px-3 py-2.5 text-base font-medium text-slate-800 hover:bg-slate-50 rounded-lg"
              >
                {link.label}
              </a>
            ))}
            <a
              href="#contact"
              onClick={(e) => {
                e.preventDefault();
                handleLinkClick('contact');
              }}
              className="px-3 py-2.5 text-base font-medium text-slate-800 hover:bg-slate-50 rounded-lg"
            >
              Contact
            </a>
          </nav>

          <div className="pt-3 border-t border-slate-200 flex items-center gap-3">
            {activeMember ? (
              <>
                <button
                  type="button"
                  onClick={() => {
                    setMobileOpen(false);
                    onNavigate('dashboard');
                  }}
                  className="flex-1 py-2.5 px-4 text-sm font-semibold text-white bg-slate-900 rounded-lg cursor-pointer"
                >
                  My Dashboard
                </button>
                <button
                  type="button"
                  onClick={() => {
                    setMobileOpen(false);
                    onLogout();
                  }}
                  className="py-2.5 px-4 text-sm font-medium text-slate-700 border border-slate-300 rounded-lg cursor-pointer"
                >
                  Sign Out
                </button>
              </>
            ) : (
              <>
                <button
                  type="button"
                  onClick={() => {
                    setMobileOpen(false);
                    onNavigate('login');
                  }}
                  className="flex-1 py-2.5 px-4 text-sm font-semibold text-slate-800 border border-slate-300 rounded-lg hover:bg-slate-50 cursor-pointer"
                >
                  Login
                </button>
                <button
                  type="button"
                  onClick={() => {
                    setMobileOpen(false);
                    onNavigate('signup');
                  }}
                  className="flex-1 py-2.5 px-4 text-sm font-semibold text-white bg-red-600 hover:bg-red-700 rounded-lg cursor-pointer"
                >
                  Sign Up
                </button>
              </>
            )}
          </div>
        </div>
      )}
    </header>
  );
}
