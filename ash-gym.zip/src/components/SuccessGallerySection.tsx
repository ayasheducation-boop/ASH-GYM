import { useEffect, useRef, useState, type PointerEvent, type TouchEvent } from 'react';
import { User } from 'lucide-react';
import { SUCCESS_PHOTO_STORIES } from '../data/gymData';

export function SuccessGallerySection() {
  const [failedImages, setFailedImages] = useState<Record<string, boolean>>({});
  const [isDesktop, setIsDesktop] = useState(false);
  const [activePage, setActivePage] = useState(0);
  const [manualOverride, setManualOverride] = useState(false);
  const dragStartXRef = useRef<number | null>(null);

  useEffect(() => {
    const mq = window.matchMedia('(min-width: 1024px)');
    const sync = () => setIsDesktop(mq.matches);
    sync();
    mq.addEventListener('change', sync);
    return () => mq.removeEventListener('change', sync);
  }, []);

  const cardsPerPage = isDesktop ? 3 : 2;
  const pages = [];
  for (let i = 0; i < SUCCESS_PHOTO_STORIES.length; i += cardsPerPage) {
    pages.push(SUCCESS_PHOTO_STORIES.slice(i, i + cardsPerPage));
  }
  const totalPages = pages.length;
  const safeActivePage = Math.min(activePage, totalPages - 1);

  useEffect(() => {
    if (manualOverride || totalPages <= 1) return;
    const timer = window.setInterval(() => {
      setActivePage((prev) => (prev + 1) % totalPages);
    }, 5000);
    return () => window.clearInterval(timer);
  }, [manualOverride, totalPages]);

  const handleManualSelect = (nextPage: number) => {
    setManualOverride(true);
    setActivePage(((nextPage % totalPages) + totalPages) % totalPages);
  };

  const handlePointerDown = (e: PointerEvent<HTMLDivElement>) => {
    if (e.pointerType === 'mouse' && e.button !== 0) return;
    dragStartXRef.current = e.clientX;
  };

  const handlePointerUp = (e: PointerEvent<HTMLDivElement>) => {
    if (dragStartXRef.current === null) return;
    const deltaX = e.clientX - dragStartXRef.current;
    dragStartXRef.current = null;
    if (Math.abs(deltaX) >= 40) {
      handleManualSelect(deltaX < 0 ? safeActivePage + 1 : safeActivePage - 1);
    }
  };

  const handleTouchStart = (e: TouchEvent<HTMLDivElement>) => {
    dragStartXRef.current = e.touches[0]?.clientX ?? null;
  };

  const handleTouchEnd = (e: TouchEvent<HTMLDivElement>) => {
    if (dragStartXRef.current === null) return;
    const endX = e.changedTouches[0]?.clientX ?? dragStartXRef.current;
    const deltaX = endX - dragStartXRef.current;
    dragStartXRef.current = null;
    if (Math.abs(deltaX) >= 40) {
      handleManualSelect(deltaX < 0 ? safeActivePage + 1 : safeActivePage - 1);
    }
  };

  return (
    <section
      aria-label="Member transformation photo stories"
      className="w-full bg-slate-50/60 py-12 sm:py-16 md:py-20 border-t border-slate-200/80 overflow-hidden"
    >
      <div className="max-w-[1280px] mx-auto px-3 sm:px-6 lg:px-8">
        <div className="flex flex-col sm:flex-row sm:items-end justify-between gap-2 sm:gap-4 mb-6 sm:mb-8">
          <div className="space-y-2 max-w-xl">
            <p className="text-xs sm:text-sm font-semibold text-red-600">
              Member Life Stories
            </p>
            <h2
              className="text-2xl sm:text-4xl font-bold tracking-tight text-slate-950 text-balance"
              style={{ fontFamily: 'var(--font-display)' }}
            >
              Real Transformations Inside ASH GYM
            </h2>
          </div>
          <p className="text-xs sm:text-sm text-slate-500">
            Swipe left or right to browse member stories
          </p>
        </div>

        {/* Swipeable Stories Carousel */}
        <div
          data-testid="story-carousel"
          data-active-page={safeActivePage}
          aria-roledescription="carousel"
          aria-label="Member Life Stories"
          onPointerDown={handlePointerDown}
          onPointerUp={handlePointerUp}
          onTouchStart={handleTouchStart}
          onTouchEnd={handleTouchEnd}
          className="w-full overflow-hidden select-none touch-pan-y cursor-grab active:cursor-grabbing"
        >
          <div
            className="flex w-full transition-transform duration-500 ease-out"
            style={{ transform: `translate3d(-${safeActivePage * 100}%, 0, 0)` }}
          >
            {pages.map((pageStories, pageIdx) => (
              <div
                key={`story-page-${pageIdx}`}
                className="w-full shrink-0 grid grid-cols-2 lg:grid-cols-3 gap-3 sm:gap-6"
              >
                {pageStories.map((story) => (
                  <article
                    key={story.id}
                    data-testid="story-card"
                    className="bg-white border border-slate-200/90 rounded-2xl overflow-hidden flex flex-col hover:border-slate-300 transition-colors duration-150"
                  >
                    <div className="aspect-[4/3] w-full bg-slate-100 overflow-hidden">
                      {!failedImages[story.id] ? (
                        <img
                          src={story.image}
                          alt={story.imageAlt}
                          referrerPolicy="no-referrer"
                          draggable={false}
                          onError={() =>
                            setFailedImages((prev) => ({ ...prev, [story.id]: true }))
                          }
                          className="w-full h-full object-cover object-top"
                        />
                      ) : (
                        <div className="w-full h-full flex items-center justify-center bg-slate-100 text-slate-400">
                          <User className="w-10 h-10" aria-hidden="true" />
                        </div>
                      )}
                    </div>

                    <div className="p-3.5 sm:p-5 flex-1 flex flex-col justify-between space-y-2.5 sm:space-y-3">
                      <div>
                        <p className="text-[11px] sm:text-xs font-medium text-slate-500 mb-1 truncate">
                          {story.program} · Age {story.age}
                        </p>
                        <h3 className="text-sm sm:text-base font-bold text-slate-950 truncate">
                          {story.name}
                        </h3>
                        <p
                          className="text-sm sm:text-base font-bold text-red-600 mt-0.5 tabular-nums leading-tight"
                          style={{ fontFamily: 'var(--font-display)' }}
                        >
                          {story.milestone}
                        </p>
                      </div>

                      <p className="text-xs sm:text-sm text-slate-600 leading-relaxed line-clamp-3 sm:line-clamp-none">
                        {story.lifeStory}
                      </p>
                    </div>
                  </article>
                ))}
              </div>
            ))}
          </div>
        </div>

        {/* Dot Swipe Counter */}
        <div
          data-testid="story-dots"
          role="tablist"
          aria-label="Member story pages"
          className="mt-6 flex items-center justify-center gap-2"
        >
          {pages.map((_, idx) => {
            const isActive = idx === safeActivePage;
            return (
              <button
                key={`story-dot-${idx}`}
                type="button"
                role="tab"
                aria-selected={isActive}
                aria-label={`Story set ${idx + 1} of ${totalPages}`}
                onClick={() => handleManualSelect(idx)}
                className={`h-2.5 rounded-full transition-all duration-200 cursor-pointer ${
                  isActive
                    ? 'w-7 bg-slate-950'
                    : 'w-2.5 bg-slate-300 hover:bg-slate-400'
                }`}
              />
            );
          })}
        </div>
      </div>
    </section>
  );
}
