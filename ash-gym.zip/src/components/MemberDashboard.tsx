import { useState, type FormEvent } from 'react';
import {
  AlertCircle,
  Calendar,
  Check,
  CheckCircle2,
  CreditCard,
  Dumbbell,
  MapPin,
  Phone,
  User,
} from 'lucide-react';
import type { GoalOption, MemberProfile, PageView } from '../types/gym';
import {
  calculateBMIFromFeetNotation,
  formatInchesToFeetInches,
  getDaysRemaining,
  getGoalWorkoutPlan,
  inchesToFeetNotation,
  parseFeetNotationToInches,
} from '../utils/bmi';
import { BMIAssessmentCard } from './BMIAssessmentCard';

interface MemberDashboardProps {
  member: MemberProfile;
  onUpdateMember: (updated: MemberProfile) => void;
  onNavigate: (view: PageView) => void;
}

const GOAL_OPTIONS: GoalOption[] = [
  'Weight Loss',
  'Weight Gain',
  'Strength Training',
  'Yoga & Mobility',
  'Athletic Conditioning',
  'General Fitness',
];

export function MemberDashboard({
  member,
  onUpdateMember,
  onNavigate,
}: MemberDashboardProps) {
  const [heightFeet, setHeightFeet] = useState(() =>
    inchesToFeetNotation(member.heightInches)
  );
  const [weightKg, setWeightKg] = useState(String(member.weightKg));
  const [goal, setGoal] = useState<GoalOption>(member.goal);
  const [savedFeedback, setSavedFeedback] = useState(false);

  const currentBmi = calculateBMIFromFeetNotation(Number(weightKg), heightFeet);
  const workoutPlan = getGoalWorkoutPlan(goal, currentBmi);
  const daysRemaining = getDaysRemaining(member.membershipExpiresAt);
  const feetLabel = formatInchesToFeetInches(member.heightInches);
  const feetShort = inchesToFeetNotation(member.heightInches);

  const latestTransaction = member.transactions[0];
  const currentMonthFeeApproved = latestTransaction?.feeApproved ?? false;

  const handleSaveMetrics = (e: FormEvent) => {
    e.preventDefault();
    const hIn = parseFeetNotationToInches(heightFeet);
    const w = Number(weightKg);
    if (hIn === null) return;
    if (!Number.isFinite(w) || w < 20 || w > 350) return;

    onUpdateMember({
      ...member,
      heightInches: hIn,
      weightKg: w,
      goal,
    });
    setSavedFeedback(true);
    setTimeout(() => setSavedFeedback(false), 3000);
  };

  const handleApproveMonthlyFee = (txnId: string) => {
    const today = new Date().toISOString().slice(0, 10);
    onUpdateMember({
      ...member,
      transactions: member.transactions.map((txn) =>
        txn.id === txnId
          ? {
              ...txn,
              feeApproved: true,
              date: today,
              method: 'Online Member Portal',
            }
          : txn
      ),
    });
  };

  return (
    <main className="w-full bg-slate-50/70 min-h-[calc(100vh-4rem)] py-8 sm:py-12">
      <div className="max-w-[1280px] mx-auto px-4 sm:px-6 lg:px-8 space-y-6 sm:space-y-8">
        {/* Member Profile Header Card */}
        <section className="bg-white border border-slate-200/90 rounded-2xl p-5 sm:p-8 flex flex-col md:flex-row md:items-center justify-between gap-5 sm:gap-6">
          <div className="flex items-center gap-4 sm:gap-5">
            <div className="w-16 h-16 sm:w-20 sm:h-20 rounded-full bg-slate-100 border border-slate-200 overflow-hidden flex items-center justify-center shrink-0">
              {member.profilePicture ? (
                <img
                  src={member.profilePicture}
                  alt={member.fullName}
                  className="w-full h-full object-cover"
                />
              ) : (
                <User className="w-8 h-8 sm:w-9 sm:h-9 text-slate-400" aria-hidden="true" />
              )}
            </div>

            <div className="space-y-1.5 min-w-0">
              <h1
                className="text-2xl sm:text-3xl font-bold text-slate-950 tracking-tight"
                style={{ fontFamily: 'var(--font-display)' }}
              >
                Welcome, {member.fullName}
              </h1>
              <p className="text-xs sm:text-sm text-slate-600 tabular-nums">
                @{member.username} · {member.age} yrs · {member.gender} ·{' '}
                {feetShort} ft ({feetLabel}) · {member.weightKg} kg · Goal:{' '}
                <span className="font-semibold text-red-600">{member.goal}</span>
              </p>
              <div className="flex flex-wrap items-center gap-x-4 gap-y-1 text-xs text-slate-500 pt-0.5">
                <span className="inline-flex items-center gap-1.5">
                  <Phone className="w-3.5 h-3.5 text-slate-400" aria-hidden="true" />
                  {member.phone}
                </span>
                <span className="inline-flex items-center gap-1.5">
                  <MapPin className="w-3.5 h-3.5 text-slate-400" aria-hidden="true" />
                  {member.address}
                </span>
                <span className="inline-flex items-center gap-1.5">
                  <Calendar className="w-3.5 h-3.5 text-slate-400" aria-hidden="true" />
                  {member.membershipPlanName}
                </span>
              </div>
            </div>
          </div>

          <button
            type="button"
            onClick={() => onNavigate('landing')}
            className="px-4 py-2.5 text-sm font-semibold text-slate-800 border border-slate-300 rounded-xl hover:bg-slate-50 transition-colors duration-150 cursor-pointer self-start md:self-center shrink-0"
          >
            View Studio Programs
          </button>
        </section>

        {/* 4-Card Member Attendance, Expiry & Monthly Fee Summary (Database-Synced Read-Only Attendance) */}
        <section
          aria-label="Member attendance, expiry, and fee status"
          className="grid grid-cols-2 lg:grid-cols-4 gap-3.5 sm:gap-5"
        >
          {/* Gym Active Days (Database-Driven Read-Only) */}
          <div className="bg-white border border-slate-200/90 rounded-2xl p-4 sm:p-6 flex flex-col justify-between gap-3">
            <div>
              <p className="text-xs font-medium text-slate-500">Gym Active</p>
              <p
                data-testid="dashboard-active-days"
                className="text-2xl sm:text-3xl font-bold text-slate-950 mt-1.5 tabular-nums tracking-tight"
                style={{ fontFamily: 'var(--font-display)' }}
              >
                {member.activeDays} Days
              </p>
            </div>
            <p className="pt-2.5 border-t border-slate-100 text-xs text-slate-500">
              Studio attendance record
            </p>
          </div>

          {/* Inactive Days (Database-Driven Read-Only, Label: Inactive) */}
          <div className="bg-white border border-slate-200/90 rounded-2xl p-4 sm:p-6 flex flex-col justify-between gap-3">
            <div>
              <p className="text-xs font-medium text-slate-500">Inactive</p>
              <p
                data-testid="dashboard-inactive-days"
                className="text-2xl sm:text-3xl font-bold text-slate-950 mt-1.5 tabular-nums tracking-tight"
                style={{ fontFamily: 'var(--font-display)' }}
              >
                {member.inactiveDays} Days
              </p>
            </div>
            <p className="pt-2.5 border-t border-slate-100 text-xs text-slate-500">
              Recorded missed days
            </p>
          </div>

          {/* Membership Expiry */}
          <div className="bg-white border border-slate-200/90 rounded-2xl p-4 sm:p-6 flex flex-col justify-between gap-3">
            <div>
              <p className="text-xs font-medium text-slate-500">
                Membership Expiry
              </p>
              <p
                data-testid="dashboard-expiry-days"
                className="text-2xl sm:text-3xl font-bold text-slate-950 mt-1.5 tabular-nums tracking-tight"
                style={{ fontFamily: 'var(--font-display)' }}
              >
                {daysRemaining} Days Left
              </p>
            </div>
            <p className="pt-2.5 border-t border-slate-100 text-xs text-slate-600 tabular-nums">
              {daysRemaining > 7 ? 'Active' : 'Renew soon'} · Until {member.membershipExpiresAt}
            </p>
          </div>

          {/* Current Monthly Fee Approval */}
          <div className="bg-white border border-slate-200/90 rounded-2xl p-4 sm:p-6 flex flex-col justify-between gap-3">
            <div>
              <p className="text-xs font-medium text-slate-500">
                Monthly Fee Status
              </p>
              <div
                data-testid="dashboard-fee-status"
                className={`mt-2 inline-flex items-center gap-1.5 text-xs sm:text-sm font-semibold ${
                  currentMonthFeeApproved ? 'text-emerald-700' : 'text-amber-700'
                }`}
              >
                {currentMonthFeeApproved ? (
                  <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" aria-hidden="true" />
                ) : (
                  <AlertCircle className="w-4 h-4 text-amber-600 shrink-0" aria-hidden="true" />
                )}
                <span>
                  {currentMonthFeeApproved
                    ? 'Monthly Fee Approved'
                    : 'Fee Not Paid'}
                </span>
              </div>
              {latestTransaction && (
                <p className="text-xs text-slate-500 mt-1 tabular-nums">
                  {latestTransaction.monthLabel} · ${latestTransaction.amount}
                </p>
              )}
            </div>

            {latestTransaction && !latestTransaction.feeApproved ? (
              <button
                type="button"
                onClick={() => handleApproveMonthlyFee(latestTransaction.id)}
                className="inline-flex items-center justify-center gap-1.5 px-3 py-2 text-xs font-semibold text-white bg-red-600 hover:bg-red-700 rounded-lg cursor-pointer transition-colors"
              >
                <CreditCard className="w-3.5 h-3.5 shrink-0" aria-hidden="true" />
                <span>Pay &amp; Approve</span>
              </button>
            ) : (
              <p className="pt-2.5 border-t border-slate-100 text-xs text-emerald-700 font-medium">
                Paid &amp; verified
              </p>
            )}
          </div>
        </section>

        <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 sm:gap-8 items-start">
          {/* Left: Fitness Type Done, Weekly Split, Transactions & Measurements */}
          <div className="lg:col-span-7 space-y-6">
            {/* Fitness Type Done in Gym (Database-Synced Display) */}
            <section className="bg-white border border-slate-200/90 rounded-2xl p-5 sm:p-8 space-y-4">
              <div>
                <h2
                  className="text-xl sm:text-2xl font-bold text-slate-950 tracking-tight"
                  style={{ fontFamily: 'var(--font-display)' }}
                >
                  Fitness Types Done in Gym
                </h2>
                <p className="text-xs sm:text-sm text-slate-500 mt-1">
                  Training disciplines recorded on your studio profile
                </p>
              </div>

              <div className="flex flex-wrap gap-2.5 pt-1">
                {member.fitnessTypesDone.map((type) => (
                  <span
                    key={type}
                    className="inline-flex items-center gap-2 px-3.5 py-2 text-xs sm:text-sm font-medium text-slate-800 bg-slate-50 border border-slate-200/80 rounded-xl"
                  >
                    <Dumbbell className="w-3.5 h-3.5 text-red-600 shrink-0" aria-hidden="true" />
                    <span>{type}</span>
                  </span>
                ))}
              </div>
            </section>

            {/* Personalized Weekly Plan */}
            <section className="bg-white border border-slate-200/90 rounded-2xl p-5 sm:p-8 space-y-5">
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 pb-4 border-b border-slate-100">
                <div>
                  <p className="text-xs font-semibold text-red-600 mb-1">
                    Personalized Training Split
                  </p>
                  <h2
                    className="text-xl sm:text-2xl font-bold text-slate-950 tracking-tight"
                    style={{ fontFamily: 'var(--font-display)' }}
                  >
                    {workoutPlan.headline}
                  </h2>
                </div>
                <span className="text-xs font-medium text-slate-500 tabular-nums">
                  {workoutPlan.frequency}
                </span>
              </div>

              <div className="divide-y divide-slate-100">
                {workoutPlan.sessions.map((session) => (
                  <div
                    key={session.day}
                    className="py-3.5 first:pt-0 last:pb-0 flex items-start gap-3"
                  >
                    <Calendar className="w-4 h-4 text-red-600 shrink-0 mt-0.5" aria-hidden="true" />
                    <div>
                      <p className="text-sm font-semibold text-slate-950">
                        {session.day} — {session.focus}
                      </p>
                      <p className="text-xs sm:text-sm text-slate-600 mt-0.5">
                        {session.detail}
                      </p>
                    </div>
                  </div>
                ))}
              </div>
            </section>

            {/* Payment & Monthly Fee Transactions */}
            <section className="bg-white border border-slate-200/90 rounded-2xl p-5 sm:p-8 space-y-4">
              <div>
                <h2
                  className="text-xl sm:text-2xl font-bold text-slate-950 tracking-tight"
                  style={{ fontFamily: 'var(--font-display)' }}
                >
                  Payment &amp; Monthly Fee Transactions
                </h2>
                <p className="text-xs sm:text-sm text-slate-500 mt-0.5">
                  Monthly fee approval status and payment history
                </p>
              </div>

              <div className="overflow-x-auto">
                <table className="w-full text-left border-collapse text-sm">
                  <thead>
                    <tr className="border-b border-slate-200 text-xs font-semibold text-slate-500">
                      <th className="py-2.5 pr-4">Month</th>
                      <th className="py-2.5 pr-4">Amount</th>
                      <th className="py-2.5 pr-4">Date</th>
                      <th className="py-2.5 pr-4">Status</th>
                      <th className="py-2.5 text-right">Reference</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-100">
                    {member.transactions.map((txn) => (
                      <tr key={txn.id}>
                        <td className="py-3 pr-4 font-medium text-slate-900">
                          {txn.monthLabel}
                          <span className="block text-xs text-slate-500 font-normal">
                            {txn.method}
                          </span>
                        </td>
                        <td className="py-3 pr-4 font-semibold text-slate-900 tabular-nums">
                          ${txn.amount}
                        </td>
                        <td className="py-3 pr-4 text-xs text-slate-600 tabular-nums">
                          {txn.date}
                        </td>
                        <td className="py-3 pr-4">
                          <span
                            className={`inline-flex items-center gap-1.5 text-xs font-semibold whitespace-nowrap ${
                              txn.feeApproved ? 'text-emerald-700' : 'text-amber-700'
                            }`}
                          >
                            {txn.feeApproved ? (
                              <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600" aria-hidden="true" />
                            ) : (
                              <AlertCircle className="w-3.5 h-3.5 text-amber-600" aria-hidden="true" />
                            )}
                            <span>{txn.feeApproved ? 'Approved' : 'Not Paid'}</span>
                          </span>
                        </td>
                        <td className="py-3 text-right">
                          {!txn.feeApproved ? (
                            <button
                              type="button"
                              onClick={() => handleApproveMonthlyFee(txn.id)}
                              className="px-3 py-1.5 text-xs font-semibold text-white bg-red-600 hover:bg-red-700 rounded-lg cursor-pointer whitespace-nowrap"
                            >
                              Pay Now
                            </button>
                          ) : (
                            <span className="text-xs text-slate-400 tabular-nums">
                              {txn.id}
                            </span>
                          )}
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </section>

            {/* Quick Update Measurements Form */}
            <section className="bg-white border border-slate-200/90 rounded-2xl p-5 sm:p-8">
              <h2
                className="text-xl font-bold text-slate-950 mb-4 tracking-tight"
                style={{ fontFamily: 'var(--font-display)' }}
              >
                Update Measurements or Goal
              </h2>

              <form
                onSubmit={handleSaveMetrics}
                className="grid grid-cols-1 sm:grid-cols-3 gap-4 items-end"
              >
                <div>
                  <label
                    htmlFor="dash-height"
                    className="block text-xs font-medium text-slate-700 mb-1.5"
                  >
                    Height (ft · e.g. 5.7)
                  </label>
                  <input
                    id="dash-height"
                    type="text"
                    inputMode="decimal"
                    value={heightFeet}
                    onChange={(e) => setHeightFeet(e.target.value)}
                    placeholder="5.7"
                    className="w-full px-3.5 py-2.5 text-sm border border-slate-300 rounded-xl tabular-nums focus:outline-none focus:border-slate-900"
                  />
                </div>
                <div>
                  <label
                    htmlFor="dash-weight"
                    className="block text-xs font-medium text-slate-700 mb-1.5"
                  >
                    Weight (kg)
                  </label>
                  <input
                    id="dash-weight"
                    type="number"
                    min={20}
                    max={350}
                    step="0.1"
                    value={weightKg}
                    onChange={(e) => setWeightKg(e.target.value)}
                    className="w-full px-3.5 py-2.5 text-sm border border-slate-300 rounded-xl tabular-nums focus:outline-none focus:border-slate-900"
                  />
                </div>
                <div>
                  <label
                    htmlFor="dash-goal"
                    className="block text-xs font-medium text-slate-700 mb-1.5"
                  >
                    Training Goal
                  </label>
                  <select
                    id="dash-goal"
                    value={goal}
                    onChange={(e) => setGoal(e.target.value as GoalOption)}
                    className="w-full px-3.5 py-2.5 text-sm border border-slate-300 rounded-xl bg-white focus:outline-none focus:border-slate-900"
                  >
                    {GOAL_OPTIONS.map((opt) => (
                      <option key={opt} value={opt}>
                        {opt}
                      </option>
                    ))}
                  </select>
                </div>

                <div className="sm:col-span-3 flex items-center gap-3 pt-1">
                  <button
                    type="submit"
                    className="px-5 py-2.5 text-sm font-semibold text-white bg-slate-900 hover:bg-slate-800 rounded-xl cursor-pointer transition-colors"
                  >
                    Save Progress
                  </button>
                  {savedFeedback && (
                    <span className="inline-flex items-center gap-1.5 text-xs font-semibold text-emerald-700">
                      <Check className="w-4 h-4" aria-hidden="true" />
                      <span>Updated</span>
                    </span>
                  )}
                </div>
              </form>
            </section>
          </div>

          {/* Right: Live BMI Card */}
          <aside className="lg:col-span-5">
            <BMIAssessmentCard
              heightFeet={heightFeet}
              weightKg={weightKg}
              currentGoal={goal}
              onApplySuggestedGoal={(suggested) => setGoal(suggested)}
            />
          </aside>
        </div>
      </div>
    </main>
  );
}
