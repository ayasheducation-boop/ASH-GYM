import { useState } from 'react';
import { Clock, MapPin } from 'lucide-react';
import { TIMETABLE_SLOTS } from '../data/gymData';
import type { TimetableSlot } from '../types/gym';

type GenderFilter = 'All' | TimetableSlot['genderAccess'];

const GENDER_FILTERS: { label: string; value: GenderFilter }[] = [
  { label: 'All Timings', value: 'All' },
  { label: 'Male Only', value: 'Male' },
  { label: 'Female Only', value: 'Female' },
  { label: 'Both (Mixed)', value: 'Both' },
];

export function TimetableSection() {
  const [filter, setFilter] = useState<GenderFilter>('All');

  const visibleSlots =
    filter === 'All'
      ? TIMETABLE_SLOTS
      : TIMETABLE_SLOTS.filter((slot) => slot.genderAccess === filter);

  const accessBadgeStyle = (access: TimetableSlot['genderAccess']) => {
    if (access === 'Male') {
      return 'text-sky-700 bg-sky-50/80';
    }
    if (access === 'Female') {
      return 'text-rose-700 bg-rose-50/80';
    }
    return 'text-emerald-700 bg-emerald-50/80';
  };

  return (
    <section
      id="timetable"
      className="w-full bg-slate-50/60 border-t border-slate-200/80 py-12 sm:py-16 md:py-24"
    >
      <div className="max-w-[1280px] mx-auto px-3 sm:px-6 lg:px-8">
        <div className="flex flex-col md:flex-row md:items-end justify-between gap-4 sm:gap-6 mb-7 sm:mb-10">
          <div className="max-w-xl space-y-2.5">
            <p className="text-xs sm:text-sm font-semibold text-red-600">
              Studio Schedule &amp; Gender Access
            </p>
            <h2
              className="text-2xl sm:text-4xl font-bold tracking-tight text-slate-950 text-balance"
              style={{ fontFamily: 'var(--font-display)' }}
            >
              Daily Gym Timetable (Male, Female &amp; Mixed Hours)
            </h2>
            <p className="text-slate-600 text-sm sm:text-base leading-relaxed">
              Clear daily floor windows for Male-only, Female-only, and Both (co-ed) training batches.
            </p>
          </div>

          <div
            role="tablist"
            aria-label="Filter gym timetable by gender access"
            className="grid grid-cols-4 sm:inline-flex sm:flex-nowrap items-center gap-1 p-1 bg-white border border-slate-200/90 rounded-xl w-full sm:w-auto self-start"
          >
            {GENDER_FILTERS.map((opt) => (
              <button
                key={opt.value}
                type="button"
                role="tab"
                aria-selected={filter === opt.value}
                onClick={() => setFilter(opt.value)}
                className={`px-2 sm:px-3.5 py-1.5 text-xs sm:text-sm font-medium rounded-lg transition-colors duration-150 whitespace-nowrap text-center cursor-pointer ${
                  filter === opt.value
                    ? 'bg-slate-950 text-white'
                    : 'text-slate-600 hover:text-slate-950'
                }`}
              >
                <span className="sm:hidden">
                  {opt.value === 'All' ? 'All' : opt.value}
                </span>
                <span className="hidden sm:inline">{opt.label}</span>
              </button>
            ))}
          </div>
        </div>

        {/* Clean Single-Surface 2-Column Timetable Cards with Prominent Time Display */}
        <div className="grid grid-cols-2 gap-2.5 sm:gap-5">
          {visibleSlots.map((slot) => (
            <div
              key={slot.id}
              data-testid="timetable-card"
              className="bg-white border border-slate-200/90 rounded-2xl p-3 sm:p-6 flex flex-col justify-between gap-3 hover:border-slate-300 transition-colors duration-150"
            >
              <div className="space-y-2.5 sm:space-y-3">
                {/* Meta Row: Access Category + Days */}
                <div className="flex items-center justify-between gap-1.5">
                  <span
                    className={`inline-flex items-center px-2 py-0.5 rounded-md text-[11px] sm:text-xs font-semibold shrink-0 ${accessBadgeStyle(
                      slot.genderAccess
                    )}`}
                  >
                    <span className="sm:hidden">{slot.genderAccess}</span>
                    <span className="hidden sm:inline">
                      {slot.genderAccess === 'Both'
                        ? 'Both (Male & Female)'
                        : `${slot.genderAccess} Only`}
                    </span>
                  </span>

                  <span className="text-[11px] sm:text-xs font-medium text-slate-500 whitespace-nowrap">
                    {slot.days}
                  </span>
                </div>

                {/* Highlighted Time Display */}
                <div className="flex items-center gap-1.5 sm:gap-3 px-2 py-1.5 sm:px-3.5 sm:py-2.5 rounded-xl bg-red-50/70 border border-red-100">
                  <span className="inline-flex items-center justify-center w-5 h-5 sm:w-8 sm:h-8 rounded-md sm:rounded-lg bg-red-600 text-white shrink-0">
                    <Clock className="w-3 h-3 sm:w-4 sm:h-4" aria-hidden="true" />
                  </span>
                  <span
                    className="text-[11px] min-[400px]:text-xs sm:text-xl md:text-[22px] font-bold text-slate-950 tabular-nums tracking-tight whitespace-nowrap leading-none"
                    style={{ fontFamily: 'var(--font-display)' }}
                  >
                    {slot.timeRange}
                  </span>
                </div>

                <h3 className="text-xs sm:text-base font-semibold text-slate-800 leading-snug line-clamp-2 sm:line-clamp-none">
                  {slot.sessionTitle}
                </h3>
              </div>

              <div className="pt-2.5 sm:pt-3.5 border-t border-slate-100 flex flex-wrap items-center justify-between gap-1.5 text-[11px] sm:text-xs text-slate-500">
                <span className="truncate font-medium text-slate-600">{slot.coach}</span>
                <span className="hidden sm:inline-flex items-center gap-1">
                  <MapPin className="w-3.5 h-3.5 text-slate-400 shrink-0" aria-hidden="true" />
                  {slot.zone}
                </span>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
