import { useEffect, useRef, useState, type PointerEvent, type TouchEvent } from 'react';
import { ArrowRight, Dumbbell } from 'lucide-react';
import { HERO_SLIDES } from '../data/gymData';
import type { PageView } from '../types/gym';

interface HeroSectionProps {
  onNavigate: (view: PageView, sectionId?: string) => void;
}

export function HeroSection({ onNavigate }: HeroSectionProps) {
  const [activeIndex, setActiveIndex] = useState(0);
  const [manualOverride, setManualOverride] = useState(false);
  const [failedImages, setFailedImages] = useState<Record<string, boolean>>({});
  const dragStartXRef = useRef<number | null>(null);

  const totalSlides = HERO_SLIDES.length;

  useEffect(() => {
    if (manualOverride) return;
    const timer = window.setInterval(() => {
      setActiveIndex((prev) => (prev + 1) % totalSlides);
    }, 4500);
    return () => window.clearInterval(timer);
  }, [manualOverride, totalSlides]);

  const handleManualSelect = (nextIndex: number) => {
    setManualOverride(true);
    setActiveIndex(((nextIndex % totalSlides) + totalSlides) % totalSlides);
  };

  const handlePointerDown = (e: PointerEvent<HTMLDivElement>) => {
    if (e.pointerType === 'mouse' && e.button !== 0) return;
    dragStartXRef.current = e.clientX;
  };

  const handlePointerUp = (e: PointerEvent<HTMLDivElement>) => {
    if (dragStartXRef.current === null) return;
    const deltaX = e.clientX - dragStartXRef.current;
    dragStartXRef.current = null;
    if (Math.abs(deltaX) >= 40) {
      handleManualSelect(deltaX < 0 ? activeIndex + 1 : activeIndex - 1);
    }
  };

  const handleTouchStart = (e: TouchEvent<HTMLDivElement>) => {
    dragStartXRef.current = e.touches[0]?.clientX ?? null;
  };

  const handleTouchEnd = (e: TouchEvent<HTMLDivElement>) => {
    if (dragStartXRef.current === null) return;
    const endX = e.changedTouches[0]?.clientX ?? dragStartXRef.current;
    const deltaX = endX - dragStartXRef.current;
    dragStartXRef.current = null;
    if (Math.abs(deltaX) >= 40) {
      handleManualSelect(deltaX < 0 ? activeIndex + 1 : activeIndex - 1);
    }
  };

  return (
    <section id="top" className="w-full bg-white">
      <div className="w-full">
        <div>
          {/* Full-Width Edge-to-Edge 16:9 Swipeable Carousel with Minimal Photo-First Overlay */}
          <div
            data-testid="hero-carousel"
            data-active-slide={activeIndex}
            aria-roledescription="carousel"
            aria-label="ASH GYM Featured Highlights"
            onPointerDown={handlePointerDown}
            onPointerUp={handlePointerUp}
            onTouchStart={handleTouchStart}
            onTouchEnd={handleTouchEnd}
            className="relative w-full aspect-video min-h-[220px] sm:min-h-0 max-h-[80vh] overflow-hidden bg-slate-100 select-none touch-pan-y cursor-grab active:cursor-grabbing"
          >
            {/* Horizontal Slide Track */}
            <div
              className="flex w-full h-full transition-transform duration-500 ease-out"
              style={{ transform: `translate3d(-${activeIndex * 100}%, 0, 0)` }}
            >
              {HERO_SLIDES.map((slide) => {
                const isContain = slide.fitMode === 'contain';
                const isWhiteSlide = slide.backdropColor === '#ffffff';
                return (
                  <div
                    key={slide.id}
                    className="relative w-full h-full shrink-0"
                    style={
                      slide.backdropColor
                        ? { backgroundColor: slide.backdropColor }
                        : undefined
                    }
                  >
                    {!failedImages[slide.id] ? (
                      <img
                        src={slide.image}
                        alt={slide.imageAlt}
                        referrerPolicy="no-referrer"
                        draggable={false}
                        onError={() =>
                          setFailedImages((prev) => ({ ...prev, [slide.id]: true }))
                        }
                        className={
                          isContain
                            ? isWhiteSlide
                              ? 'w-full h-full object-contain object-center px-8 pt-2 pb-24 sm:px-16 sm:pt-4 sm:pb-28'
                              : 'w-full h-full object-contain object-center px-8 pt-2 pb-22 sm:px-16 sm:pt-4 sm:pb-24 [mask-image:radial-gradient(closest-side,black_82%,transparent_100%)]'
                            : 'w-full h-full object-cover object-center'
                        }
                      />
                    ) : (
                      <div className="w-full h-full bg-gradient-to-br from-slate-100 to-slate-200 flex items-center justify-center">
                        <Dumbbell className="w-16 h-16 text-slate-400" aria-hidden="true" />
                      </div>
                    )}

                    {/* Light Bottom-Left Gradient Scrim Keeping Studio Photo or Logo Prominent */}
                    <div
                      className={`absolute inset-0 flex flex-col justify-end p-4 pb-9 sm:p-8 md:p-14 lg:p-16 sm:pb-14 ${
                        isWhiteSlide
                          ? 'bg-[linear-gradient(to_top,rgba(255,255,255,0.98)_0%,rgba(255,255,255,0.88)_28%,rgba(255,255,255,0)_54%)]'
                          : 'bg-gradient-to-t from-slate-950/75 via-slate-950/20 to-transparent'
                      }`}
                    >
                      <div className="max-w-lg sm:max-w-xl space-y-2 sm:space-y-4">
                        <h1
                          className={`font-bold tracking-tight leading-[1.08] text-balance ${
                            isWhiteSlide ? 'text-slate-950' : 'text-white drop-shadow-xs'
                          }`}
                          style={{
                            fontFamily: 'var(--font-display)',
                            fontSize: 'clamp(1.0625rem, 3.1vw, 2.75rem)',
                          }}
                        >
                          {slide.headline}
                        </h1>
                        <div>
                          <button
                            type="button"
                            onClick={() => onNavigate('signup')}
                            className="inline-flex items-center gap-1.5 sm:gap-2 px-3.5 py-2 sm:px-5 sm:py-2.5 text-xs sm:text-sm font-semibold text-white bg-red-600 hover:bg-red-700 rounded-xl transition-colors duration-150 whitespace-nowrap shrink-0 cursor-pointer focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-red-600"
                          >
                            <span>{slide.ctaLabel}</span>
                            <ArrowRight className="w-3.5 h-3.5 sm:w-4 sm:h-4" aria-hidden="true" />
                          </button>
                        </div>
                      </div>
                    </div>
                  </div>
                );
              })}
            </div>

            {/* Bottom Dot Indicators Only */}
            <div className="absolute bottom-2 sm:bottom-4 left-1/2 -translate-x-1/2 flex items-center bg-slate-950/60 backdrop-blur-xs px-2.5 py-1 sm:px-3 sm:py-1.5 rounded-full z-10">
              <div className="flex items-center gap-2" role="tablist" aria-label="Hero slide selector">
                {HERO_SLIDES.map((slide, idx) => {
                  const isActive = idx === activeIndex;
                  return (
                    <button
                      key={slide.id}
                      type="button"
                      role="tab"
                      aria-selected={isActive}
                      aria-label={`Slide ${idx + 1} of ${totalSlides}`}
                      onClick={() => handleManualSelect(idx)}
                      className={`h-2 sm:h-2.5 rounded-full transition-all duration-200 cursor-pointer ${
                        isActive
                          ? 'w-5 sm:w-7 bg-white'
                          : 'w-2 sm:w-2.5 bg-white/45 hover:bg-white/75'
                      }`}
                    />
                  );
                })}
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
