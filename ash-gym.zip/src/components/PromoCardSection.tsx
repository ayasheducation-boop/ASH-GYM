import { ArrowRight } from 'lucide-react';

interface PromoCardSectionProps {
  onClaimOffer: () => void;
}

export function PromoCardSection({ onClaimOffer }: PromoCardSectionProps) {
  return (
    <section
      aria-label="Introductory coaching offer"
      className="w-full bg-slate-50/60 border-t border-slate-200/80 py-12 md:py-16"
    >
      <div className="max-w-[1280px] mx-auto px-4 sm:px-6 lg:px-8">
        <div className="bg-white border border-slate-200/90 rounded-2xl p-6 sm:p-10 lg:p-12 shadow-xs flex flex-col lg:flex-row lg:items-center justify-between gap-8">
          <div className="max-w-2xl space-y-2.5">
            <p className="text-xs sm:text-sm font-semibold text-red-600">
              Limited November Trial · Free BMI &amp; Movement Check
            </p>

            <h2
              className="text-2xl sm:text-4xl font-bold tracking-tight text-slate-950 text-balance"
              style={{ fontFamily: 'var(--font-display)' }}
            >
              14-Day Guided Intro Pass + Custom Workout Split for $19
            </h2>

            <p className="text-slate-600 text-sm sm:text-base leading-relaxed">
              Test full floor access, two coached strength or weight-loss classes, one yoga recovery session, and a 1-on-1 BMI &amp; goal consultation before committing monthly.
            </p>
          </div>

          <div className="shrink-0 flex flex-col sm:flex-row lg:flex-col items-stretch sm:items-center lg:items-end gap-3">
            <button
              type="button"
              onClick={onClaimOffer}
              className="inline-flex items-center justify-center gap-2 px-6 py-3.5 text-sm font-semibold text-white bg-red-600 hover:bg-red-700 rounded-xl transition-colors duration-150 whitespace-nowrap cursor-pointer"
            >
              <span>Claim 14-Day Pass</span>
              <ArrowRight className="w-4 h-4" aria-hidden="true" />
            </button>
            <p className="text-xs text-slate-500 sm:text-left lg:text-right">
              No auto-renewal · First-time members only
            </p>
          </div>
        </div>
      </div>
    </section>
  );
}
