import { useRef, useState, type ChangeEvent, type FormEvent } from 'react';
import { ArrowLeft, Trash2, Upload, User } from 'lucide-react';
import { PROGRAMS } from '../data/gymData';
import type { GenderOption, GoalOption, MemberProfile, PageView } from '../types/gym';
import {
  formatInchesToFeetInches,
  inchesToCm,
  parseFeetNotationToInches,
  validateSignupForm,
  type SignupFormValues,
  type ValidationErrors,
} from '../utils/bmi';
import { BMIAssessmentCard } from './BMIAssessmentCard';

interface SignupPageProps {
  initialGoal?: GoalOption | '';
  existingUsernames: string[];
  onCompleteSignup: (member: MemberProfile) => void;
  onNavigate: (view: PageView) => void;
}

const GOAL_OPTIONS: GoalOption[] = [
  'Weight Loss',
  'Weight Gain',
  'Strength Training',
  'Yoga & Mobility',
  'Athletic Conditioning',
  'General Fitness',
];

const GENDER_OPTIONS: GenderOption[] = [
  'Male',
  'Female',
  'Non-binary',
  'Prefer not to say',
];

export function SignupPage({
  initialGoal = '',
  existingUsernames,
  onCompleteSignup,
  onNavigate,
}: SignupPageProps) {
  const fileInputRef = useRef<HTMLInputElement>(null);

  const [values, setValues] = useState<SignupFormValues>({
    fullName: '',
    username: '',
    email: '',
    phone: '',
    address: '',
    age: '',
    heightFeet: '',
    weightKg: '',
    gender: '',
    goal: initialGoal,
    password: '',
  });

  const [profilePicture, setProfilePicture] = useState<string | undefined>(undefined);
  const [pictureError, setPictureError] = useState<string>('');
  const [errors, setErrors] = useState<ValidationErrors<keyof SignupFormValues>>({});

  const updateField = <K extends keyof SignupFormValues>(
    field: K,
    value: SignupFormValues[K]
  ) => {
    setValues((prev) => ({ ...prev, [field]: value }));
    if (errors[field]) {
      setErrors((prev) => ({ ...prev, [field]: undefined }));
    }
  };

  const handleImageUpload = (e: ChangeEvent<HTMLInputElement>) => {
    setPictureError('');
    const file = e.target.files?.[0];
    if (!file) return;

    if (!file.type.startsWith('image/')) {
      setPictureError('Please choose a valid image file (PNG, JPG, or WebP).');
      return;
    }
    if (file.size > 3 * 1024 * 1024) {
      setPictureError('Profile picture must be smaller than 3 MB.');
      return;
    }

    const reader = new FileReader();
    reader.onload = () => {
      if (typeof reader.result === 'string') {
        setProfilePicture(reader.result);
      }
    };
    reader.readAsDataURL(file);
  };

  const handleSubmit = (e: FormEvent) => {
    e.preventDefault();
    const validationErrors = validateSignupForm(values, existingUsernames);
    setErrors(validationErrors);
    if (Object.keys(validationErrors).length > 0) {
      return;
    }

    const parsedInches = parseFeetNotationToInches(values.heightFeet);
    if (parsedInches === null) return;

    const today = new Date();
    const expiryDate = new Date(today);
    expiryDate.setDate(expiryDate.getDate() + 30);

    const matchedProgram = PROGRAMS.find(
      (p) => p.goalMapping === (values.goal as GoalOption)
    );
    const monthlyFee = matchedProgram?.packagePrice ?? 119;
    const currentMonthLabel = today.toLocaleDateString('en-US', {
      month: 'long',
      year: 'numeric',
    });

    const newMember: MemberProfile = {
      id: `member-${Date.now()}`,
      fullName: values.fullName.trim(),
      username: values.username.trim().toLowerCase(),
      email: values.email.trim() || undefined,
      phone: values.phone.trim(),
      address: values.address.trim(),
      age: Number(values.age),
      heightInches: parsedInches,
      weightKg: Number(values.weightKg),
      gender: values.gender as GenderOption,
      goal: values.goal as GoalOption,
      password: values.password,
      profilePicture,
      joinedAt: today.toISOString().slice(0, 10),
      activeDays: 1,
      inactiveDays: 0,
      fitnessTypesDone: [values.goal as GoalOption],
      membershipPlanName: matchedProgram
        ? `${matchedProgram.title} Track`
        : 'Coached Group & Program',
      membershipExpiresAt: expiryDate.toISOString().slice(0, 10),
      transactions: [
        {
          id: `TXN-${today.getFullYear()}-${String(today.getMonth() + 1).padStart(2, '0')}`,
          monthLabel: currentMonthLabel,
          amount: monthlyFee,
          date: today.toISOString().slice(0, 10),
          method: 'Pending Studio Confirmation',
          feeApproved: false,
        },
      ],
    };

    onCompleteSignup(newMember);
  };

  const parsedInches = parseFeetNotationToInches(values.heightFeet);
  const feetHelper = parsedInches ? formatInchesToFeetInches(parsedInches) : '';

  return (
    <main className="w-full bg-slate-50/70 min-h-[calc(100vh-4rem)] py-10 sm:py-14">
      <div className="max-w-[1280px] mx-auto px-4 sm:px-6 lg:px-8">
        <div className="mb-8 flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <div>
            <button
              type="button"
              onClick={() => onNavigate('landing')}
              className="inline-flex items-center gap-1.5 text-sm font-medium text-slate-600 hover:text-slate-950 mb-3 cursor-pointer"
            >
              <ArrowLeft className="w-4 h-4" aria-hidden="true" />
              <span>Back to Home</span>
            </button>
            <h1
              className="text-3xl sm:text-4xl font-bold tracking-tight text-slate-950"
              style={{ fontFamily: 'var(--font-display)' }}
            >
              Create Your ASH GYM Member Profile
            </h1>
            <p className="text-sm sm:text-base text-slate-600 mt-1">
              Enter your height in feet (like 5.7) and weight in kg to unlock live BMI guidance and your personal member dashboard.
            </p>
          </div>

          <p className="text-sm text-slate-600 shrink-0">
            Already a member?{' '}
            <button
              type="button"
              onClick={() => onNavigate('login')}
              className="font-semibold text-red-600 hover:text-red-700 underline underline-offset-4 cursor-pointer"
            >
              Log in here
            </button>
          </p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
          {/* Signup Form Column */}
          <form
            onSubmit={handleSubmit}
            noValidate
            className="lg:col-span-7 bg-white border border-slate-200/90 rounded-2xl p-6 sm:p-8 space-y-6"
          >
            {/* Profile Picture Upload */}
            <div className="flex flex-col sm:flex-row sm:items-center gap-5 pb-6 border-b border-slate-200">
              <div className="w-20 h-20 rounded-full bg-slate-100 border border-slate-200 overflow-hidden flex items-center justify-center shrink-0">
                {profilePicture ? (
                  <img
                    src={profilePicture}
                    alt="Uploaded member profile preview"
                    className="w-full h-full object-cover"
                  />
                ) : (
                  <User className="w-8 h-8 text-slate-400" aria-hidden="true" />
                )}
              </div>

              <div className="space-y-2">
                <p className="text-sm font-semibold text-slate-900">
                  Profile Picture
                </p>
                <p className="text-xs text-slate-500">
                  Optional portrait for your member pass (JPG, PNG, or WebP up to 3 MB).
                </p>
                <div className="flex flex-wrap items-center gap-2.5">
                  <input
                    ref={fileInputRef}
                    id="signup-avatar"
                    type="file"
                    accept="image/*"
                    onChange={handleImageUpload}
                    className="sr-only"
                  />
                  <label
                    htmlFor="signup-avatar"
                    className="inline-flex items-center gap-2 px-3.5 py-2 text-xs font-semibold text-slate-800 bg-white border border-slate-300 hover:bg-slate-50 rounded-lg cursor-pointer"
                  >
                    <Upload className="w-3.5 h-3.5" aria-hidden="true" />
                    <span>{profilePicture ? 'Change Photo' : 'Upload Photo'}</span>
                  </label>
                  {profilePicture && (
                    <button
                      type="button"
                      onClick={() => {
                        setProfilePicture(undefined);
                        if (fileInputRef.current) fileInputRef.current.value = '';
                      }}
                      className="inline-flex items-center gap-1.5 px-3 py-2 text-xs font-medium text-red-600 hover:bg-red-50 rounded-lg cursor-pointer"
                    >
                      <Trash2 className="w-3.5 h-3.5" aria-hidden="true" />
                      <span>Remove</span>
                    </button>
                  )}
                </div>
                {pictureError && (
                  <p className="text-xs text-red-600">{pictureError}</p>
                )}
              </div>
            </div>

            {/* Identity & Contact Fields */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div>
                <label
                  htmlFor="signup-fullname"
                  className="block text-sm font-medium text-slate-800 mb-1.5"
                >
                  Full Name
                </label>
                <input
                  id="signup-fullname"
                  type="text"
                  value={values.fullName}
                  onChange={(e) => updateField('fullName', e.target.value)}
                  placeholder="Rohan Patel"
                  className="w-full px-3.5 py-2.5 text-sm text-slate-900 bg-white border border-slate-300 rounded-lg focus:outline-none focus:border-slate-900"
                />
                {errors.fullName && (
                  <p className="mt-1 text-xs text-red-600">{errors.fullName}</p>
                )}
              </div>

              <div>
                <label
                  htmlFor="signup-username"
                  className="block text-sm font-medium text-slate-800 mb-1.5"
                >
                  Username
                </label>
                <input
                  id="signup-username"
                  type="text"
                  value={values.username}
                  onChange={(e) => updateField('username', e.target.value)}
                  placeholder="rohan_fit"
                  className="w-full px-3.5 py-2.5 text-sm text-slate-900 bg-white border border-slate-300 rounded-lg focus:outline-none focus:border-slate-900"
                />
                {errors.username && (
                  <p className="mt-1 text-xs text-red-600">{errors.username}</p>
                )}
              </div>

              <div>
                <label
                  htmlFor="signup-email"
                  className="block text-sm font-medium text-slate-800 mb-1.5"
                >
                  Email <span className="text-slate-400 font-normal">(Optional)</span>
                </label>
                <input
                  id="signup-email"
                  type="email"
                  value={values.email}
                  onChange={(e) => updateField('email', e.target.value)}
                  placeholder="rohan@example.com"
                  className="w-full px-3.5 py-2.5 text-sm text-slate-900 bg-white border border-slate-300 rounded-lg focus:outline-none focus:border-slate-900"
                />
                {errors.email && (
                  <p className="mt-1 text-xs text-red-600">{errors.email}</p>
                )}
              </div>

              <div>
                <label
                  htmlFor="signup-phone"
                  className="block text-sm font-medium text-slate-800 mb-1.5"
                >
                  Phone Number
                </label>
                <input
                  id="signup-phone"
                  type="tel"
                  value={values.phone}
                  onChange={(e) => updateField('phone', e.target.value)}
                  placeholder="+1 555 234 5678"
                  className="w-full px-3.5 py-2.5 text-sm text-slate-900 bg-white border border-slate-300 rounded-lg focus:outline-none focus:border-slate-900 tabular-nums"
                />
                {errors.phone && (
                  <p className="mt-1 text-xs text-red-600">{errors.phone}</p>
                )}
              </div>
            </div>

            <div>
              <label
                htmlFor="signup-address"
                className="block text-sm font-medium text-slate-800 mb-1.5"
              >
                Address
              </label>
              <input
                id="signup-address"
                type="text"
                value={values.address}
                onChange={(e) => updateField('address', e.target.value)}
                placeholder="42 Maple Avenue, West District"
                className="w-full px-3.5 py-2.5 text-sm text-slate-900 bg-white border border-slate-300 rounded-lg focus:outline-none focus:border-slate-900"
              />
              {errors.address && (
                <p className="mt-1 text-xs text-red-600">{errors.address}</p>
              )}
            </div>

            {/* Body Metrics for Live BMI */}
            <div className="pt-2 border-t border-slate-200">
              <p className="text-sm font-semibold text-slate-900 mb-3">
                Body Metrics &amp; Training Goal
              </p>
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
                <div>
                  <label
                    htmlFor="signup-age"
                    className="block text-sm font-medium text-slate-800 mb-1.5"
                  >
                    Age (Years)
                  </label>
                  <input
                    id="signup-age"
                    type="number"
                    min={13}
                    max={100}
                    value={values.age}
                    onChange={(e) => updateField('age', e.target.value)}
                    placeholder="26"
                    className="w-full px-3.5 py-2.5 text-sm text-slate-900 bg-white border border-slate-300 rounded-lg focus:outline-none focus:border-slate-900 tabular-nums"
                  />
                  {errors.age && (
                    <p className="mt-1 text-xs text-red-600">{errors.age}</p>
                  )}
                </div>

                <div>
                  <label
                    htmlFor="signup-height"
                    className="block text-sm font-medium text-slate-800 mb-1.5"
                  >
                    Height (ft)
                  </label>
                  <input
                    id="signup-height"
                    type="text"
                    inputMode="decimal"
                    value={values.heightFeet}
                    onChange={(e) => updateField('heightFeet', e.target.value)}
                    placeholder="5.7"
                    className="w-full px-3.5 py-2.5 text-sm text-slate-900 bg-white border border-slate-300 rounded-lg focus:outline-none focus:border-slate-900 tabular-nums"
                  />
                  {feetHelper && parsedInches !== null && !errors.heightFeet ? (
                    <p className="mt-1 text-xs text-slate-500 tabular-nums">
                      {feetHelper} · {inchesToCm(parsedInches)} cm
                    </p>
                  ) : !errors.heightFeet ? (
                    <p className="mt-1 text-xs text-slate-400">
                      Example: 5.7 = 5 ft 7 in
                    </p>
                  ) : null}
                  {errors.heightFeet && (
                    <p className="mt-1 text-xs text-red-600">{errors.heightFeet}</p>
                  )}
                </div>

                <div>
                  <label
                    htmlFor="signup-weight"
                    className="block text-sm font-medium text-slate-800 mb-1.5"
                  >
                    Weight (kg)
                  </label>
                  <input
                    id="signup-weight"
                    type="number"
                    min={20}
                    max={350}
                    step="0.1"
                    value={values.weightKg}
                    onChange={(e) => updateField('weightKg', e.target.value)}
                    placeholder="72"
                    className="w-full px-3.5 py-2.5 text-sm text-slate-900 bg-white border border-slate-300 rounded-lg focus:outline-none focus:border-slate-900 tabular-nums"
                  />
                  {errors.weightKg && (
                    <p className="mt-1 text-xs text-red-600">{errors.weightKg}</p>
                  )}
                </div>
              </div>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div>
                <label
                  htmlFor="signup-gender"
                  className="block text-sm font-medium text-slate-800 mb-1.5"
                >
                  Gender
                </label>
                <select
                  id="signup-gender"
                  value={values.gender}
                  onChange={(e) =>
                    updateField('gender', e.target.value as GenderOption | '')
                  }
                  className="w-full px-3.5 py-2.5 text-sm text-slate-900 bg-white border border-slate-300 rounded-lg focus:outline-none focus:border-slate-900"
                >
                  <option value="">Select gender</option>
                  {GENDER_OPTIONS.map((opt) => (
                    <option key={opt} value={opt}>
                      {opt}
                    </option>
                  ))}
                </select>
                {errors.gender && (
                  <p className="mt-1 text-xs text-red-600">{errors.gender}</p>
                )}
              </div>

              <div>
                <label
                  htmlFor="signup-goal"
                  className="block text-sm font-medium text-slate-800 mb-1.5"
                >
                  Training Goal
                </label>
                <select
                  id="signup-goal"
                  value={values.goal}
                  onChange={(e) =>
                    updateField('goal', e.target.value as GoalOption | '')
                  }
                  className="w-full px-3.5 py-2.5 text-sm text-slate-900 bg-white border border-slate-300 rounded-lg focus:outline-none focus:border-slate-900"
                >
                  <option value="">Select your goal</option>
                  {GOAL_OPTIONS.map((opt) => (
                    <option key={opt} value={opt}>
                      {opt}
                    </option>
                  ))}
                </select>
                {errors.goal && (
                  <p className="mt-1 text-xs text-red-600">{errors.goal}</p>
                )}
              </div>
            </div>

            <div>
              <label
                htmlFor="signup-password"
                className="block text-sm font-medium text-slate-800 mb-1.5"
              >
                Account Password
              </label>
              <input
                id="signup-password"
                type="password"
                value={values.password}
                onChange={(e) => updateField('password', e.target.value)}
                placeholder="At least 6 characters"
                className="w-full px-3.5 py-2.5 text-sm text-slate-900 bg-white border border-slate-300 rounded-lg focus:outline-none focus:border-slate-900"
              />
              {errors.password && (
                <p className="mt-1 text-xs text-red-600">{errors.password}</p>
              )}
            </div>

            <button
              type="submit"
              className="w-full py-3.5 px-6 text-sm font-semibold text-white bg-red-600 hover:bg-red-700 rounded-lg transition-colors duration-150 cursor-pointer"
            >
              Complete Signup &amp; Build My Plan
            </button>
          </form>

          {/* Live Automatic BMI Assessment Column */}
          <aside className="lg:col-span-5 lg:sticky lg:top-24">
            <BMIAssessmentCard
              heightFeet={values.heightFeet}
              weightKg={values.weightKg}
              currentGoal={values.goal}
              onApplySuggestedGoal={(suggested) => updateField('goal', suggested)}
            />
          </aside>
        </div>
      </div>
    </main>
  );
}
