import { useState } from 'react';
import { Check } from 'lucide-react';
import { PRICING_PLANS } from '../data/gymData';

interface PricingSectionProps {
  onChoosePlan: () => void;
}

export function PricingSection({ onChoosePlan }: PricingSectionProps) {
  const [billing, setBilling] = useState<'monthly' | 'annual'>('monthly');

  return (
    <section
      id="pricing"
      className="w-full bg-white border-t border-slate-200/80 py-12 sm:py-16 md:py-24"
    >
      <div className="max-w-[1280px] mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex flex-col md:flex-row md:items-end justify-between gap-6 mb-8 sm:mb-12">
          <div className="max-w-xl space-y-2.5">
            <p className="text-xs sm:text-sm font-semibold text-red-600">
              Transparent Membership
            </p>
            <h2
              className="text-2xl sm:text-4xl font-bold tracking-tight text-slate-950 text-balance"
              style={{ fontFamily: 'var(--font-display)' }}
            >
              Simple Pricing Plans With Zero Hidden Fees
            </h2>
            <p className="text-slate-600 text-sm sm:text-base leading-relaxed">
              Every plan includes your baseline BMI check and onboarding walkthrough.
            </p>
          </div>

          <div
            role="group"
            aria-label="Billing cycle"
            className="inline-flex items-center p-1 bg-slate-100/80 border border-slate-200/80 rounded-xl self-start"
          >
            <button
              type="button"
              onClick={() => setBilling('monthly')}
              aria-pressed={billing === 'monthly'}
              className={`px-3.5 sm:px-4 py-1.5 sm:py-2 text-xs sm:text-sm font-medium rounded-lg transition-colors duration-150 whitespace-nowrap shrink-0 cursor-pointer ${
                billing === 'monthly'
                  ? 'bg-white text-slate-950 shadow-xs'
                  : 'text-slate-600 hover:text-slate-950'
              }`}
            >
              Monthly Billing
            </button>
            <button
              type="button"
              onClick={() => setBilling('annual')}
              aria-pressed={billing === 'annual'}
              className={`px-3.5 sm:px-4 py-1.5 sm:py-2 text-xs sm:text-sm font-medium rounded-lg transition-colors duration-150 whitespace-nowrap shrink-0 cursor-pointer ${
                billing === 'annual'
                  ? 'bg-white text-slate-950 shadow-xs'
                  : 'text-slate-600 hover:text-slate-950'
              }`}
            >
              Annual (Save 20%)
            </button>
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-5 sm:gap-6 items-stretch">
          {PRICING_PLANS.map((plan) => {
            const price =
              billing === 'monthly' ? plan.monthlyPrice : plan.annualPrice;
            return (
              <div
                key={plan.id}
                data-testid="pricing-card"
                className={`flex flex-col bg-white rounded-2xl p-6 lg:p-8 border transition-shadow duration-200 ${
                  plan.featured
                    ? 'border-red-600 ring-1 ring-red-600/15 shadow-sm'
                    : 'border-slate-200/90 hover:border-slate-300'
                }`}
              >
                <div className="mb-5">
                  <div className="flex items-center justify-between gap-2 mb-1.5">
                    <h3
                      className="text-xl sm:text-2xl font-bold text-slate-950 tracking-tight leading-tight"
                      style={{ fontFamily: 'var(--font-display)' }}
                    >
                      {plan.name}
                    </h3>
                    {plan.featured && (
                      <span className="text-xs font-semibold text-red-600 shrink-0">
                        Most Popular
                      </span>
                    )}
                  </div>
                  <p className="text-sm text-slate-600 leading-relaxed">
                    {plan.tagline}
                  </p>
                </div>

                <div className="pb-5 mb-5 border-b border-slate-100 flex items-baseline gap-2">
                  <span
                    className="text-4xl font-bold text-slate-950 tabular-nums tracking-tight"
                    style={{ fontFamily: 'var(--font-display)' }}
                  >
                    ${price}
                  </span>
                  <span className="text-sm text-slate-500">
                    / month {billing === 'annual' ? '· billed annually' : ''}
                  </span>
                </div>

                <ul className="space-y-3 text-sm text-slate-700 mb-7 flex-1">
                  {plan.features.map((feat) => (
                    <li key={feat} className="flex items-start gap-2.5">
                      <Check
                        className="w-4 h-4 text-red-600 shrink-0 mt-0.5"
                        aria-hidden="true"
                      />
                      <span className="leading-snug">{feat}</span>
                    </li>
                  ))}
                </ul>

                <button
                  type="button"
                  onClick={onChoosePlan}
                  className={`w-full py-3 px-5 text-sm font-semibold rounded-xl transition-colors duration-150 cursor-pointer ${
                    plan.featured
                      ? 'bg-red-600 hover:bg-red-700 text-white'
                      : 'bg-slate-950 hover:bg-slate-800 text-white'
                  }`}
                >
                  {plan.ctaLabel}
                </button>
              </div>
            );
          })}
        </div>
      </div>
    </section>
  );
}
