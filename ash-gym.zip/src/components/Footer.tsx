import type { PageView } from '../types/gym';

interface FooterProps {
  onNavigate: (view: PageView, sectionId?: string) => void;
}

export function Footer({ onNavigate }: FooterProps) {
  return (
    <footer className="w-full bg-white border-t border-slate-200/80 py-12">
      <div className="max-w-[1280px] mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-8 pb-10 border-b border-slate-200/80">
          <div className="space-y-3">
            <span
              className="text-2xl font-bold tracking-tight uppercase text-slate-950 inline-block"
              style={{ fontFamily: 'var(--font-display)' }}
            >
              ASH GYM
            </span>
            <p className="text-sm text-slate-600 leading-relaxed max-w-xs">
              Bright, coach-led personal training studio dedicated to measurable strength, healthy weight goals, and everyday mobility.
            </p>
          </div>

          <div>
            <h3 className="text-sm font-semibold text-slate-950 mb-3">
              Programs
            </h3>
            <ul className="space-y-2 text-sm text-slate-600">
              <li>
                <a
                  href="#programs"
                  onClick={(e) => {
                    e.preventDefault();
                    onNavigate('landing', 'programs');
                  }}
                  className="hover:text-slate-950"
                >
                  Weight Gain
                </a>
              </li>
              <li>
                <a
                  href="#programs"
                  onClick={(e) => {
                    e.preventDefault();
                    onNavigate('landing', 'programs');
                  }}
                  className="hover:text-slate-950"
                >
                  Weight Loss
                </a>
              </li>
              <li>
                <a
                  href="#programs"
                  onClick={(e) => {
                    e.preventDefault();
                    onNavigate('landing', 'programs');
                  }}
                  className="hover:text-slate-950"
                >
                  Strength Training
                </a>
              </li>
              <li>
                <a
                  href="#programs"
                  onClick={(e) => {
                    e.preventDefault();
                    onNavigate('landing', 'programs');
                  }}
                  className="hover:text-slate-950"
                >
                  Yoga &amp; Mobility
                </a>
              </li>
            </ul>
          </div>

          <div>
            <h3 className="text-sm font-semibold text-slate-950 mb-3">
              Studio
            </h3>
            <ul className="space-y-2 text-sm text-slate-600">
              <li>
                <a
                  href="#timetable"
                  onClick={(e) => {
                    e.preventDefault();
                    onNavigate('landing', 'timetable');
                  }}
                  className="hover:text-slate-950"
                >
                  Gym Timetable
                </a>
              </li>
              <li>
                <a
                  href="#pricing"
                  onClick={(e) => {
                    e.preventDefault();
                    onNavigate('landing', 'pricing');
                  }}
                  className="hover:text-slate-950"
                >
                  Pricing Plans
                </a>
              </li>
              <li>
                <a
                  href="#testimonials"
                  onClick={(e) => {
                    e.preventDefault();
                    onNavigate('landing', 'testimonials');
                  }}
                  className="hover:text-slate-950"
                >
                  Client Stories
                </a>
              </li>
              <li>
                <a
                  href="#blog"
                  onClick={(e) => {
                    e.preventDefault();
                    onNavigate('landing', 'blog');
                  }}
                  className="hover:text-slate-950"
                >
                  Training Blog
                </a>
              </li>
              <li>
                <a
                  href="#faq"
                  onClick={(e) => {
                    e.preventDefault();
                    onNavigate('landing', 'faq');
                  }}
                  className="hover:text-slate-950"
                >
                  FAQ
                </a>
              </li>
            </ul>
          </div>

          <div>
            <h3 className="text-sm font-semibold text-slate-950 mb-3">
              Member Portal
            </h3>
            <ul className="space-y-2 text-sm text-slate-600">
              <li>
                <button
                  type="button"
                  onClick={() => onNavigate('signup')}
                  className="hover:text-slate-950 cursor-pointer"
                >
                  Create Member Account
                </button>
              </li>
              <li>
                <button
                  type="button"
                  onClick={() => onNavigate('login')}
                  className="hover:text-slate-950 cursor-pointer"
                >
                  Member Login
                </button>
              </li>
              <li className="text-xs text-slate-500 pt-2">
                428 Mercer Street, West District
              </li>
              <li className="text-xs text-slate-500 tabular-nums">
                Mon–Sat 6:00 AM – 10:00 PM
              </li>
            </ul>
          </div>
        </div>

        <div className="pt-6 flex flex-col sm:flex-row items-center justify-between gap-4 text-xs text-slate-500">
          <p>© {new Date().getFullYear()} ASH GYM. All rights reserved.</p>
          <p>Personal Training · Strength · Yoga</p>
        </div>
      </div>
    </footer>
  );
}
