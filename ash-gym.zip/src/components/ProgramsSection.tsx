import { useState } from 'react';
import { ArrowRight, Check, Dumbbell } from 'lucide-react';
import { PROGRAMS } from '../data/gymData';
import type { GoalOption } from '../types/gym';

interface ProgramsSectionProps {
  onSelectGoalForSignup: (goal: GoalOption) => void;
}

export function ProgramsSection({ onSelectGoalForSignup }: ProgramsSectionProps) {
  const [failedImages, setFailedImages] = useState<Record<string, boolean>>({});

  return (
    <section id="programs" className="w-full bg-white py-12 sm:py-16 md:py-24">
      <div className="max-w-[1280px] mx-auto px-3 sm:px-6 lg:px-8">
        <div className="max-w-2xl mb-8 sm:mb-12 space-y-2.5">
          <p className="text-xs sm:text-sm font-semibold text-red-600">
            Four Core Training Tracks
          </p>
          <h2
            className="text-2xl sm:text-4xl font-bold tracking-tight text-slate-950 text-balance"
            style={{ fontFamily: 'var(--font-display)' }}
          >
            Programs Built Around Measurable Goals
          </h2>
          <p className="text-slate-600 text-sm sm:text-base leading-relaxed">
            Every track pairs coached form instruction with clear weekly targets and transparent package pricing.
          </p>
        </div>

        <div className="grid grid-cols-2 lg:grid-cols-4 gap-3 sm:gap-6">
          {PROGRAMS.map((program) => (
            <article
              key={program.id}
              data-testid="program-card"
              className="group flex flex-col bg-white border border-slate-200/90 rounded-2xl overflow-hidden transition-all duration-200 hover:border-slate-300 hover:shadow-sm"
            >
              <div className="aspect-[4/3] w-full overflow-hidden bg-slate-100">
                {!failedImages[program.id] ? (
                  <img
                    src={program.image}
                    alt={program.imageAlt}
                    referrerPolicy="no-referrer"
                    onError={() =>
                      setFailedImages((prev) => ({ ...prev, [program.id]: true }))
                    }
                    className="w-full h-full object-cover object-center transition-transform duration-300 group-hover:scale-[1.03]"
                  />
                ) : (
                  <div className="w-full h-full flex flex-col items-center justify-center bg-slate-100 text-slate-500 gap-2 p-4">
                    <Dumbbell className="w-8 h-8" aria-hidden="true" />
                    <span className="text-sm font-semibold">{program.title}</span>
                  </div>
                )}
              </div>

              <div className="flex-1 p-3.5 sm:p-5 flex flex-col">
                <div className="flex items-baseline justify-between gap-1.5 mb-1.5 sm:mb-2">
                  <h3
                    className="text-base sm:text-xl font-bold text-slate-950 tracking-tight leading-tight"
                    style={{ fontFamily: 'var(--font-display)' }}
                  >
                    {program.title}
                  </h3>
                  <div className="shrink-0">
                    <span
                      className="text-sm sm:text-lg font-bold text-red-600 tabular-nums"
                      style={{ fontFamily: 'var(--font-display)' }}
                    >
                      ${program.packagePrice}
                    </span>
                    <span className="text-[10px] sm:text-xs text-slate-500 ml-0.5">
                      /mo
                    </span>
                  </div>
                </div>

                <p className="text-[11px] sm:text-xs font-medium text-slate-500 mb-2 sm:mb-3 tabular-nums">
                  {program.duration}
                  <span aria-hidden="true" className="hidden sm:inline"> · </span>
                  <span className="hidden sm:inline">{program.sessionsPerWeek}</span>
                </p>

                <p className="text-xs sm:text-sm text-slate-600 leading-relaxed mb-3.5 sm:mb-5 line-clamp-3 sm:line-clamp-none">
                  {program.summary}
                </p>

                <ul className="hidden sm:block space-y-2 mb-6 pt-3.5 border-t border-slate-100 text-xs text-slate-700 flex-1">
                  {program.highlights.map((item) => (
                    <li key={item} className="flex items-start gap-2">
                      <Check
                        className="w-3.5 h-3.5 text-red-600 shrink-0 mt-0.5"
                        aria-hidden="true"
                      />
                      <span>{item}</span>
                    </li>
                  ))}
                </ul>

                <button
                  type="button"
                  onClick={() => onSelectGoalForSignup(program.goalMapping)}
                  className="mt-auto w-full inline-flex items-center justify-center gap-1.5 px-3 py-2 sm:px-4 sm:py-2.5 text-xs sm:text-sm font-semibold text-slate-900 bg-white hover:bg-slate-950 hover:text-white border border-slate-200 hover:border-slate-950 rounded-xl transition-colors duration-150 cursor-pointer"
                >
                  <span className="sm:hidden">Select Track</span>
                  <span className="hidden sm:inline">Choose {program.title}</span>
                  <ArrowRight className="w-3.5 h-3.5 sm:w-4 sm:h-4 shrink-0" aria-hidden="true" />
                </button>
              </div>
            </article>
          ))}
        </div>
      </div>
    </section>
  );
}
