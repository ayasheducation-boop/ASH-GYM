import type {
  BlogPost,
  FaqItem,
  HeroSlide,
  MemberProfile,
  PricingPlan,
  ProgramItem,
  SuccessPhotoStory,
  TestimonialItem,
  TimetableSlot,
} from '../types/gym';

export const HERO_SLIDES: HeroSlide[] = [
  {
    id: 'slide-studio',
    kicker: 'Personal Training · Strength Coaching · Yoga & Mobility',
    headline: 'Train With Precision. Build Strength That Lasts.',
    subheadline:
      'Coach-led programs for Weight Gain, Weight Loss, Barbell Strength, and Yoga—backed by instant BMI goal planning on day one.',
    ctaLabel: 'Start Your Plan',
    image: '/src/assets/images/hero_ash_gym_1794812786995.jpg',
    imageAlt:
      'ASH GYM sunlit personal training studio with squat racks, turf lane, and coach guiding a lifter',
  },
  {
    id: 'slide-strength',
    kicker: 'Barbell Coaching · Hypertrophy · Progressive Overload',
    headline: 'Master Every Lift With Direct Coach Guidance.',
    subheadline:
      'Dedicated strength platforms, calibrated steel plates, and structured progression blocks tailored to your body metrics.',
    ctaLabel: 'Join Strength Track',
    image: '/src/assets/images/hero_slide_strength_1794813778868.jpg',
    imageAlt:
      'Athlete setting up a barbell deadlift on an oak platform with personal trainer coaching posture',
  },
  {
    id: 'slide-yoga',
    kicker: 'Morning Vinyasa · Joint Mobility · Active Recovery',
    headline: 'Restore Mobility, Balance, and Daily Energy.',
    subheadline:
      'Pair heavy training days with sunlit yoga and breathwork sessions designed to protect hips, spine, and shoulders.',
    ctaLabel: 'Book Yoga & Mobility',
    image: '/src/assets/images/hero_slide_yoga_1794813778239.jpg',
    imageAlt:
      'Instructor guiding athletes through balanced warrior poses in a bright sunlit hardwood yoga studio',
  },
  {
    id: 'slide-custom-floor',
    kicker: 'Strength Floor · Free Weights · Kettlebell Zone',
    headline: 'Complete Free-Weight Floor Built For Daily Progress.',
    subheadline:
      'Dumbbell racks, kettlebells, and structured functional lanes ready for morning and evening sessions.',
    ctaLabel: 'Explore Studio Floor',
    image: '/src/assets/images/hero_custom_1.jpg',
    imageAlt: 'ASH GYM free-weight studio floor with dumbbell rack, kettlebells, and wooden slat wall',
    fitMode: 'cover',
  },
  {
    id: 'slide-custom-brand-dark',
    kicker: 'ASH GYM & Studio Lounge · Strength · Recovery',
    headline: 'Train Hard. Recover Right Under One Roof.',
    subheadline:
      'Dedicated strength programming paired with an athlete recovery lounge for post-session fueling.',
    ctaLabel: 'Start Membership',
    image: '/src/assets/images/hero_custom_2.jpg',
    imageAlt: 'Studio emblem banner with warm orange typography on dark slate backdrop',
    fitMode: 'contain',
    backdropColor: '#060708',
  },
  {
    id: 'slide-custom-logo-white',
    kicker: 'ASH GYM · Personal Training · Community Fuel',
    headline: 'Your Neighborhood Strength & Fuel Destination.',
    subheadline:
      'Guided lifting sessions, nutrition coaching, and community energy every single day.',
    ctaLabel: 'Join ASH GYM',
    image: '/src/assets/images/ash_gym_logo.png',
    imageAlt: 'ASH GYM signature lifter and recovery cup emblem on clean white canvas',
    fitMode: 'contain',
    backdropColor: '#ffffff',
  },
];

export interface TickerAnnouncement {
  id: string;
  timeOrDay: string;
  text: string;
  iconType: 'clock' | 'calendar' | 'dumbbell' | 'heart';
}

export const TICKER_ANNOUNCEMENTS: TickerAnnouncement[] = [
  {
    id: 't1',
    timeOrDay: '6:00 AM – 10:00 PM',
    text: 'Open Gym & Coaching Hours',
    iconType: 'clock',
  },
  {
    id: 't2',
    timeOrDay: '10:00 AM – 1:00 PM',
    text: 'Women-Only Floor Batch',
    iconType: 'heart',
  },
  {
    id: 't3',
    timeOrDay: 'Mon 7:00 AM',
    text: 'Strength Foundations — 4 Spots Open',
    iconType: 'dumbbell',
  },
  {
    id: 't4',
    timeOrDay: 'Sunday 9:00 AM',
    text: 'Free Member BMI Check-In',
    iconType: 'calendar',
  },
  {
    id: 't5',
    timeOrDay: '14-Day Trial',
    text: '$19 Intro Pass + Custom Split',
    iconType: 'clock',
  },
];

export const PROGRAMS: ProgramItem[] = [
  {
    id: 'weight-gain',
    title: 'Weight Gain',
    goalMapping: 'Weight Gain',
    packagePrice: 109,
    pricePeriod: '/ month',
    sessionsPerWeek: '4 Sessions / Wk',
    duration: '55 Min',
    level: 'Lean Mass Focus',
    summary:
      'Structured progressive overload paired with simple calorie-surplus meal targets to build clean muscle mass without unwanted fat gain.',
    highlights: [
      'Compound barbell & dumbbell hypertrophy blocks',
      'Weekly weight & strength progression tracking',
      'High-protein meal timing blueprint',
    ],
    image: '/src/assets/images/program_weight_gain_1794812787234.jpg',
    imageAlt: 'Athlete performing incline dumbbell press in a bright gym studio',
  },
  {
    id: 'weight-loss',
    title: 'Weight Loss',
    goalMapping: 'Weight Loss',
    packagePrice: 99,
    pricePeriod: '/ month',
    sessionsPerWeek: '4–5 Sessions / Wk',
    duration: '45 Min',
    level: 'Metabolic Burn',
    summary:
      'Joint-friendly circuit strength and steady conditioning engineered to shed body fat while preserving lean muscle and daily energy.',
    highlights: [
      'Kettlebell, sled, and ergometer conditioning blocks',
      'Sustainable calorie deficit without crash diets',
      'Bi-weekly waist and BMI milestone reviews',
    ],
    image: '/src/assets/images/program_weight_loss_1794812787782.jpg',
    imageAlt: 'Athlete conditioning with kettlebell swings and battle ropes on turf',
  },
  {
    id: 'strength-training',
    title: 'Strength Training',
    goalMapping: 'Strength Training',
    packagePrice: 119,
    pricePeriod: '/ month',
    sessionsPerWeek: '4 Sessions / Wk',
    duration: '60 Min',
    level: 'All Levels',
    summary:
      'Master squat, hinge, press, and pull mechanics under direct coach supervision to increase raw power, posture, and bone density.',
    highlights: [
      'Technique coaching on barbell squat, deadlift, and press',
      'Periodized 12-week strength progression cycles',
      'Accessory work for shoulder and lower-back resilience',
    ],
    image: '/src/assets/images/program_strength_training_1794812789350.jpg',
    imageAlt: 'Athlete setting up for a barbell deadlift on an oak lifting platform',
  },
  {
    id: 'yoga',
    title: 'Yoga',
    goalMapping: 'Yoga & Mobility',
    packagePrice: 79,
    pricePeriod: '/ month',
    sessionsPerWeek: '3–4 Sessions / Wk',
    duration: '50 Min',
    level: 'Mobility & Calm',
    summary:
      'Guided breathwork, joint decompression, and flow sequences that restore hip and shoulder range of motion and accelerate recovery.',
    highlights: [
      'Morning Vinyasa and evening restorative sequences',
      'Targeted hip, thoracic, and hamstring mobility drills',
      'Breathing protocols to lower resting stress',
    ],
    image: '/src/assets/images/program_yoga_1794812788387.jpg',
    imageAlt: 'Athlete practicing Warrior II yoga pose in a sunlit hardwood studio',
  },
];

export const TIMETABLE_SLOTS: TimetableSlot[] = [
  {
    id: 'tt-1',
    timeRange: '6:00 AM – 8:30 AM',
    days: 'Mon – Sat',
    genderAccess: 'Both',
    sessionTitle: 'Morning Open Floor, Strength & Conditioning',
    coach: 'Coach Ash Verma',
    zone: 'Main Barbell & Turf Floor',
  },
  {
    id: 'tt-2',
    timeRange: '8:30 AM – 10:00 AM',
    days: 'Mon – Sat',
    genderAccess: 'Male',
    sessionTitle: 'Men’s Barbell Strength & Hypertrophy Batch',
    coach: 'Coach Ash Verma',
    zone: 'Oak Lifting Platforms',
  },
  {
    id: 'tt-3',
    timeRange: '10:00 AM – 1:00 PM',
    days: 'Mon – Sat',
    genderAccess: 'Female',
    sessionTitle: 'Women-Only Strength, Toning & Yoga Recovery',
    coach: 'Coach Rhea Sen',
    zone: 'Full Studio (Private Access)',
  },
  {
    id: 'tt-4',
    timeRange: '1:00 PM – 4:00 PM',
    days: 'Mon – Sat',
    genderAccess: 'Both',
    sessionTitle: 'Midday Open Gym & 1-on-1 Personal Coaching',
    coach: 'Coaching Staff',
    zone: 'All Studio Zones',
  },
  {
    id: 'tt-5',
    timeRange: '4:00 PM – 6:00 PM',
    days: 'Mon – Fri',
    genderAccess: 'Female',
    sessionTitle: 'Afternoon Women’s Fat Loss & Mobility Circuit',
    coach: 'Coach Rhea Sen',
    zone: 'Turf & Yoga Studio',
  },
  {
    id: 'tt-6',
    timeRange: '6:00 PM – 8:00 PM',
    days: 'Mon – Sat',
    genderAccess: 'Male',
    sessionTitle: 'Evening Men’s Weight Gain & Powerlifting',
    coach: 'Coach Ash Verma',
    zone: 'Main Strength Floor',
  },
  {
    id: 'tt-7',
    timeRange: '8:00 PM – 10:00 PM',
    days: 'Mon – Sat',
    genderAccess: 'Both',
    sessionTitle: 'Late Evening Mixed Open Floor & Restorative Yoga',
    coach: 'Coach Ash & Coach Rhea',
    zone: 'All Studio Zones',
  },
  {
    id: 'tt-8',
    timeRange: '7:30 AM – 4:00 PM',
    days: 'Sunday',
    genderAccess: 'Both',
    sessionTitle: 'Sunday Mobility Flow & Weekly BMI Check-Ins',
    coach: 'Coach Rhea Sen',
    zone: 'Hardwood Yoga & Assessment Room',
  },
];

export const PRICING_PLANS: PricingPlan[] = [
  {
    id: 'starter-floor',
    name: 'Open Studio',
    tagline: 'Full floor access with initial BMI assessment and program template.',
    monthlyPrice: 49,
    annualPrice: 39,
    ctaLabel: 'Start Open Studio',
    features: [
      'Unlimited floor access (6:00 AM – 10:00 PM)',
      'Initial BMI & movement baseline check',
      'Access to 2 Yoga mobility classes per week',
      'Digital workout log & goal dashboard',
    ],
  },
  {
    id: 'personal-coaching',
    name: 'Coached Group & Program',
    tagline: 'Our most chosen plan with weekly coach check-ins and small-group sessions.',
    monthlyPrice: 119,
    annualPrice: 95,
    featured: true,
    ctaLabel: 'Join Coached Plan',
    features: [
      'Everything in Open Studio access',
      '4 coach-led Strength, Weight Loss, or Gain sessions weekly',
      'Unlimited Yoga & Mobility classes',
      'Custom calorie & protein targets adjusted monthly',
      'Bi-weekly form review and BMI progress check',
    ],
  },
  {
    id: 'one-on-one',
    name: '1-on-1 Personal Trainer',
    tagline: 'Dedicated private coaching with Coach Ash for tailored transformation.',
    monthlyPrice: 249,
    annualPrice: 199,
    ctaLabel: 'Book 1-on-1 Coaching',
    features: [
      '12 private 1-on-1 training sessions per month',
      'Custom daily meal prep & travel workout adjustments',
      'Direct coach messaging for schedule & recovery',
      'Full movement screening & posture correction plan',
    ],
  },
];

export const TESTIMONIALS: TestimonialItem[] = [
  {
    id: 'story-1',
    name: 'Priya Nair',
    role: 'Product Designer, 29',
    program: 'Weight Loss & Mobility',
    metric: '-12.5 kg in 16 Weeks',
    timeframe: '16 Weeks · BMI 28.4 to 23.1',
    quote:
      'Coach Ash never put me on an extreme diet. Three strength circuits and two rowing mornings a week fixed my back stiffness and brought my BMI comfortably into the healthy range.',
    image: '/src/assets/images/client_portrait_one_1794812789100.jpg',
    initials: 'PN',
  },
  {
    id: 'story-2',
    name: 'Daniel Brooks',
    role: 'Civil Engineer, 33',
    program: 'Weight Gain & Strength',
    metric: '+8.2 kg Lean Mass',
    timeframe: '20 Weeks · Deadlift 100 kg to 165 kg',
    quote:
      'I spent years spinning my wheels trying to gain weight. Having structured compound lifts and clear post-workout meal targets helped me add solid muscle without feeling sluggish.',
    image: '/src/assets/images/client_portrait_two_1794812790004.jpg',
    initials: 'DB',
  },
  {
    id: 'story-3',
    name: 'Hannah Kim',
    role: 'Pediatric Nurse, 36',
    program: 'Strength & Yoga',
    metric: 'Zero Lower-Back Pain',
    timeframe: '12 Weeks · 4 Sessions Weekly',
    quote:
      'Twelve-hour hospital shifts left my shoulders and hips locked up. Pairing barbell deadlift coaching with Wednesday evening yoga completely changed how I move at work.',
    initials: 'HK',
  },
];

export const SUCCESS_PHOTO_STORIES: SuccessPhotoStory[] = [
  {
    id: 'sg-1',
    name: 'Priya Nair',
    age: 29,
    program: 'Weight Loss',
    milestone: 'Down 12.5 kg · 16 Weeks',
    lifeStory:
      'Returned to pain-free 5 km morning runs after cutting knee strain through kettlebell strength and guided fat loss.',
    image: '/src/assets/images/client_portrait_one_1794812789100.jpg',
    imageAlt: 'Priya Nair smiling inside ASH GYM studio',
  },
  {
    id: 'sg-2',
    name: 'Daniel Brooks',
    age: 33,
    program: 'Weight Gain',
    milestone: 'Up 8.2 kg Lean Mass',
    lifeStory:
      'Moved from underweight BMI 18.1 to 21.4 with 4 days of compound barbell lifts and consistent protein prep.',
    image: '/src/assets/images/client_portrait_two_1794812790004.jpg',
    imageAlt: 'Daniel Brooks in the gym after strength training',
  },
  {
    id: 'sg-3',
    name: 'Claire & Tessa Bennett',
    age: 35,
    program: 'Strength & Conditioning',
    milestone: 'First 100 kg Deadlift',
    lifeStory:
      'Training together in the 10:00 AM women-only batch built accountability and reversed years of desk posture fatigue.',
    image: '/src/assets/images/story_transformation_three_1794813779585.jpg',
    imageAlt: 'Claire and Tessa smiling after a morning kettlebell session',
  },
  {
    id: 'sg-4',
    name: 'Lucas Fernandez',
    age: 28,
    program: 'Strength Training',
    milestone: 'Squat 75 kg to 140 kg',
    lifeStory:
      'Recovered from an ankle sprain with Coach Ash’s progressive squat plan and Saturday mobility sessions.',
    image: '/src/assets/images/story_transformation_four_1794813779314.jpg',
    imageAlt: 'Lucas Fernandez standing beside an oak squat rack in the gym',
  },
  {
    id: 'sg-5',
    name: 'Elena Rostova',
    age: 31,
    program: 'Yoga & Mobility',
    milestone: 'Full Shoulder Mobility Restored',
    lifeStory:
      'Combined morning Vinyasa flows with controlled dumbbell pressing to eliminate chronic neck tension.',
    image: '/src/assets/images/program_yoga_1794812788387.jpg',
    imageAlt: 'Elena practicing Warrior II pose in the sunlit yoga room',
  },
  {
    id: 'sg-6',
    name: 'Marcus Reid',
    age: 34,
    program: 'Weight Gain',
    milestone: '+6 kg Muscle · 14 Weeks',
    lifeStory:
      'Built upper-body strength and daily stamina with structured incline pressing and clean calorie targets.',
    image: '/src/assets/images/program_weight_gain_1794812787234.jpg',
    imageAlt: 'Athlete performing incline dumbbell press in the daylight studio',
  },
];

export const BLOG_POSTS: BlogPost[] = [
  {
    id: 'protein-meal-prep',
    title: 'How to Hit Your Daily Protein Target Without Complicated Meal Prep',
    category: 'Nutrition',
    readTime: '4 min read',
    publishedDate: 'Nov 8, 2026',
    author: 'Coach Ash Verma',
    excerpt:
      'A practical three-bowl formula that works whether your goal is steady fat loss or lean weight gain.',
    image: '/src/assets/images/blog_nutrition_prep_1794812788717.jpg',
    imageAlt:
      'Three balanced meal prep bowls with grilled protein, quinoa, avocado, and roasted sweet potatoes',
    body: [
      'Most people abandon nutrition plans not because they lack willpower, but because tracking twenty ingredients every evening takes too much time after work.',
      'At ASH GYM, we teach a simple 3-part plate framework: pick one palm-and-a-half serving of lean protein (grilled chicken, eggs, tofu, salmon, or Greek yogurt), one fist-sized complex carbohydrate (quinoa, rice, or sweet potato), and two fists of colorful vegetables.',
      'For Weight Gain clients, add a tablespoon of olive oil, avocado, or roasted nuts to bump calories cleanly by 200 kcal per meal. For Weight Loss clients, keep sauces light with lemon, herbs, and mustard while keeping protein steady so you stay full between sessions.',
    ],
  },
  {
    id: 'progressive-overload-basics',
    title: 'Progressive Overload Explained: Why Small Weight Jumps Beat Exhaustion',
    category: 'Strength',
    readTime: '5 min read',
    publishedDate: 'Oct 29, 2026',
    author: 'Coach Ash Verma',
    excerpt:
      'Leaving every workout drenched in sweat is not the same as getting stronger. Here is how to track real progress.',
    image: '/src/assets/images/program_strength_training_1794812789350.jpg',
    imageAlt: 'Barbell loaded with calibrated weight plates on an oak gym platform',
    body: [
      'Random high-intensity circuits feel tough in the moment, yet after eight weeks many lifters notice their weights and physique have stalled.',
      'Muscle and bone adapt to measurable mechanical tension. Adding just 2.5 kg to your squat or completing one extra clean repetition with identical form is a stronger signal than switching exercises every week.',
      'Keep a straightforward notebook or use your ASH GYM member log: record sets, reps, and load for your top four lifts, and aim to beat last week by one clean rep before increasing weight.',
    ],
  },
  {
    id: 'desk-mobility-reset',
    title: 'A 12-Minute Desk Reset: Unlocking Tight Hips and Rounded Shoulders',
    category: 'Mobility',
    readTime: '3 min read',
    publishedDate: 'Oct 19, 2026',
    author: 'Coach Rhea Sen',
    excerpt:
      'Three floor-based yoga and breathing drills you can run before your evening strength session.',
    image: '/src/assets/images/program_yoga_1794812788387.jpg',
    imageAlt: 'Yoga practitioner holding a balanced lunge pose on a studio mat',
    body: [
      'Eight hours in an office chair shortens hip flexors and stiffens the upper back, which makes overhead pressing and deep squatting feel pinched.',
      'Before loading a barbell, spend 12 minutes on three low-load movements: 8 slow cat-cow spinal waves, 60 seconds per side in a half-kneeling hip flexor stretch with a glute squeeze, and 10 open-book thoracic rotations.',
      'Pair every stretch with a slow 4-second nasal exhale. When your nervous system relaxes, your range of motion opens immediately without forcing joints.',
    ],
  },
  {
    id: 'conditioning-for-fat-loss',
    title: 'Why Low-Impact Conditioning Protects Joints During Weight Loss',
    category: 'Recovery',
    readTime: '4 min read',
    publishedDate: 'Oct 6, 2026',
    author: 'Coach Ash Verma',
    excerpt:
      'When your BMI sits above 27, smart conditioning builds heart capacity without beating up your knees.',
    image: '/src/assets/images/program_weight_loss_1794812787782.jpg',
    imageAlt: 'Athlete conditioning with kettlebells and battle ropes',
    body: [
      'High-impact jumping and daily pavement sprints often cause shin splints or knee irritation within the first three weeks of a new fat-loss routine.',
      'Swapping plyometrics for rowing intervals, incline treadmill walks, sled pushes, and controlled kettlebell swings delivers the same cardiovascular output with a fraction of the joint impact.',
      'Consistency over 16 weeks beats a heroic week one followed by two weeks on the couch icing sore ankles.',
    ],
  },
];

export const FAQ_ITEMS: FaqItem[] = [
  {
    id: 'faq-1',
    question: 'Which program is best for beginners?',
    answer:
      'Enter your height (e.g. 5.7 ft) and weight on Sign Up to get an instant BMI recommendation and first-day coaching walkthrough.',
  },
  {
    id: 'faq-2',
    question: 'How does automatic BMI goal suggestion work?',
    answer:
      'We calculate your BMI from your height and weight, show whether it is underweight, healthy, or overweight, and suggest a matching workout plan.',
  },
  {
    id: 'faq-3',
    question: 'Are there separate Male, Female & Mixed timings?',
    answer:
      'Yes. Our Daily Timetable lists dedicated Male-only, Female-only, and Both (mixed) studio hours every day.',
  },
  {
    id: 'faq-4',
    question: 'Is email required during member signup?',
    answer:
      'No, email is optional. Only your name, username, phone number, address, and body metrics are required.',
  },
  {
    id: 'faq-5',
    question: 'What does the Member Dashboard show?',
    answer:
      'Your dashboard tracks active and inactive gym days, fitness types done, membership expiry days, and monthly fee approval status.',
  },
  {
    id: 'faq-6',
    question: 'What are ASH GYM opening hours?',
    answer:
      'Monday to Saturday from 6:00 AM – 10:00 PM, and Sunday from 7:30 AM – 4:00 PM for mobility, Yoga, and BMI check-ins.',
  },
];

export const DEMO_MEMBERS: MemberProfile[] = [
  {
    id: 'member-demo-1',
    fullName: 'Alex Mercer',
    username: 'alex_runner',
    email: 'alex@ashgym.example',
    phone: '+1 555 219 4820',
    address: '214 Oakwood Lane, Westside',
    age: 28,
    heightInches: 70,
    weightKg: 74,
    gender: 'Male',
    goal: 'Strength Training',
    password: 'ashgym123',
    joinedAt: '2026-09-12',
    activeDays: 18,
    inactiveDays: 4,
    fitnessTypesDone: ['Strength Training', 'Kettlebell Conditioning', 'Yoga Mobility'],
    membershipPlanName: 'Coached Group & Program',
    membershipExpiresAt: '2026-12-15',
    transactions: [
      {
        id: 'TXN-2026-11',
        monthLabel: 'November 2026',
        amount: 119,
        date: '2026-11-02',
        method: 'Card / Studio Desk',
        feeApproved: true,
      },
      {
        id: 'TXN-2026-10',
        monthLabel: 'October 2026',
        amount: 119,
        date: '2026-10-02',
        method: 'Card / Studio Desk',
        feeApproved: true,
      },
      {
        id: 'TXN-2026-09',
        monthLabel: 'September 2026',
        amount: 119,
        date: '2026-09-12',
        method: 'UPI / Instant Pay',
        feeApproved: true,
      },
    ],
  },
];
