/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { useEffect, useState } from 'react';
import { DEMO_MEMBERS } from './data/gymData';
import type { GoalOption, MemberProfile, PageView } from './types/gym';
import { Header } from './components/Header';
import { HeroSection } from './components/HeroSection';
import { NewsTicker } from './components/NewsTicker';
import { ProgramsSection } from './components/ProgramsSection';
import { TimetableSection } from './components/TimetableSection';
import { PricingSection } from './components/PricingSection';
import { PromoCardSection } from './components/PromoCardSection';
import { TestimonialsSection } from './components/TestimonialsSection';
import { SuccessGallerySection } from './components/SuccessGallerySection';
import { BlogSection } from './components/BlogSection';
import { FaqSection } from './components/FaqSection';
import { ContactSection } from './components/ContactSection';
import { Footer } from './components/Footer';
import { SignupPage } from './components/SignupPage';
import { LoginPage } from './components/LoginPage';
import { MemberDashboard } from './components/MemberDashboard';

const MEMBERS_STORAGE_KEY = 'ash_gym_members_v2';
const ACTIVE_SESSION_KEY = 'ash_gym_active_username_v2';

function loadStoredMembers(): MemberProfile[] {
  try {
    const raw = localStorage.getItem(MEMBERS_STORAGE_KEY);
    if (!raw) return DEMO_MEMBERS;
    const parsed = JSON.parse(raw) as MemberProfile[];
    return Array.isArray(parsed) && parsed.length > 0 ? parsed : DEMO_MEMBERS;
  } catch {
    return DEMO_MEMBERS;
  }
}

function loadActiveMember(members: MemberProfile[]): MemberProfile | null {
  try {
    const activeUsername = localStorage.getItem(ACTIVE_SESSION_KEY);
    if (!activeUsername) return null;
    return members.find((m) => m.username === activeUsername) ?? null;
  } catch {
    return null;
  }
}

function getViewFromHash(hasActiveMember: boolean): PageView {
  const hash = window.location.hash;
  if (hash === '#/signup') return 'signup';
  if (hash === '#/login') return 'login';
  if (hash === '#/dashboard') return hasActiveMember ? 'dashboard' : 'login';
  return 'landing';
}

export default function App() {
  const [members, setMembers] = useState<MemberProfile[]>(() => loadStoredMembers());
  const [activeMember, setActiveMember] = useState<MemberProfile | null>(() =>
    loadActiveMember(loadStoredMembers())
  );
  const [currentView, setCurrentView] = useState<PageView>(() =>
    getViewFromHash(Boolean(loadActiveMember(loadStoredMembers())))
  );
  const [preselectedGoal, setPreselectedGoal] = useState<GoalOption | ''>('');

  useEffect(() => {
    const onHashChange = () => {
      setCurrentView(getViewFromHash(Boolean(activeMember)));
    };
    window.addEventListener('hashchange', onHashChange);
    return () => window.removeEventListener('hashchange', onHashChange);
  }, [activeMember]);

  useEffect(() => {
    try {
      localStorage.setItem(MEMBERS_STORAGE_KEY, JSON.stringify(members));
    } catch {
      // Ignore storage quota errors cleanly
    }
  }, [members]);

  useEffect(() => {
    try {
      if (activeMember) {
        localStorage.setItem(ACTIVE_SESSION_KEY, activeMember.username);
      } else {
        localStorage.removeItem(ACTIVE_SESSION_KEY);
      }
    } catch {
      // Ignore storage errors
    }
  }, [activeMember]);

  const handleNavigate = (view: PageView, sectionId?: string) => {
    const nextHash =
      view === 'landing'
        ? sectionId && sectionId !== 'top'
          ? `#${sectionId}`
          : '#top'
        : `#/${view}`;

    if (window.location.hash !== nextHash) {
      window.history.pushState(null, '', nextHash);
    }

    setCurrentView(view);
    if (view === 'landing' && sectionId) {
      requestAnimationFrame(() => {
        if (sectionId === 'top') {
          window.scrollTo({ top: 0, behavior: 'smooth' });
          return;
        }
        const el = document.getElementById(sectionId);
        if (el) {
          el.scrollIntoView({ behavior: 'smooth' });
        }
      });
    } else {
      window.scrollTo({ top: 0, behavior: 'instant' });
    }
  };

  const handleSelectGoalForSignup = (goal: GoalOption) => {
    setPreselectedGoal(goal);
    handleNavigate('signup');
  };

  const handleCompleteSignup = (newMember: MemberProfile) => {
    setMembers((prev) => [...prev, newMember]);
    setActiveMember(newMember);
    setPreselectedGoal('');
    handleNavigate('dashboard');
  };

  const handleLoginSuccess = (member: MemberProfile) => {
    setActiveMember(member);
    handleNavigate('dashboard');
  };

  const handleUpdateMember = (updated: MemberProfile) => {
    setMembers((prev) =>
      prev.map((m) => (m.id === updated.id ? updated : m))
    );
    setActiveMember(updated);
  };

  const handleLogout = () => {
    setActiveMember(null);
    handleNavigate('landing', 'top');
  };

  return (
    <div className="min-h-screen flex flex-col bg-white text-slate-900">
      <Header
        currentView={currentView}
        activeMember={activeMember}
        onNavigate={handleNavigate}
        onLogout={handleLogout}
      />

      {currentView === 'landing' && (
        <main className="flex-1">
          <HeroSection onNavigate={handleNavigate} />
          <NewsTicker />
          <ProgramsSection onSelectGoalForSignup={handleSelectGoalForSignup} />
          <TimetableSection />
          <PricingSection onChoosePlan={() => handleNavigate('signup')} />
          <PromoCardSection onClaimOffer={() => handleNavigate('signup')} />
          <TestimonialsSection />
          <SuccessGallerySection />
          <BlogSection />
          <FaqSection />
          <ContactSection />
        </main>
      )}

      {currentView === 'signup' && (
        <SignupPage
          initialGoal={preselectedGoal}
          existingUsernames={members.map((m) => m.username)}
          onCompleteSignup={handleCompleteSignup}
          onNavigate={handleNavigate}
        />
      )}

      {currentView === 'login' && (
        <LoginPage
          members={members}
          onLoginSuccess={handleLoginSuccess}
          onNavigate={handleNavigate}
        />
      )}

      {currentView === 'dashboard' && activeMember && (
        <MemberDashboard
          member={activeMember}
          onUpdateMember={handleUpdateMember}
          onNavigate={handleNavigate}
        />
      )}

      <Footer onNavigate={handleNavigate} />
    </div>
  );
}
