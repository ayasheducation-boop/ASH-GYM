import test from 'node:test';
import assert from 'node:assert/strict';
import {
  calculateBMI,
  calculateBMIFromFeetNotation,
  calculateBMIFromInches,
  classifyBMI,
  formatInchesToFeetInches,
  getDaysRemaining,
  getGoalWorkoutPlan,
  getHealthyWeightRangeKg,
  inchesToCm,
  inchesToFeetNotation,
  parseFeetNotationToInches,
  validateContactForm,
  validateSignupForm,
} from './bmi';

test('parseFeetNotationToInches, inchesToFeetNotation, and calculateBMIFromFeetNotation work accurately', () => {
  assert.equal(parseFeetNotationToInches('5.7'), 67);
  assert.equal(parseFeetNotationToInches('5.10'), 70);
  assert.equal(parseFeetNotationToInches('5.11'), 71);
  assert.equal(parseFeetNotationToInches('6'), 72);
  assert.equal(parseFeetNotationToInches('6.0'), 72);
  assert.equal(parseFeetNotationToInches("5'9"), 69);
  assert.equal(parseFeetNotationToInches('5.15'), null);
  assert.equal(parseFeetNotationToInches('2.5'), null);
  assert.equal(parseFeetNotationToInches('abc'), null);

  assert.equal(inchesToFeetNotation(67), '5.7');
  assert.equal(inchesToFeetNotation(70), '5.10');
  assert.equal(inchesToFeetNotation(72), '6.0');

  assert.equal(calculateBMIFromFeetNotation(72, '5.9'), 23.4);
  assert.equal(calculateBMIFromFeetNotation(68, '5.7'), 23.5);
  assert.equal(calculateBMIFromFeetNotation(72, '5.15'), null);
});

test('inchesToCm, formatInchesToFeetInches, and calculateBMIFromInches work accurately', () => {
  assert.equal(inchesToCm(69), 175.3);
  assert.equal(formatInchesToFeetInches(69), '5 ft 9 in');
  assert.equal(calculateBMIFromInches(72, 69), 23.4);
  assert.equal(calculateBMIFromInches(52, 69), 16.9);
  assert.equal(calculateBMIFromInches(98, 69), 31.9);
  assert.equal(calculateBMIFromInches(70, 20), null);
});

test('calculateBMI computes accurate rounded BMI and rejects out-of-range inputs', () => {
  assert.equal(calculateBMI(72, 175), 23.5);
  assert.equal(calculateBMI(52, 175), 17.0);
  assert.equal(calculateBMI(98, 175), 32.0);
  assert.equal(calculateBMI(0, 175), null);
  assert.equal(calculateBMI(70, 50), null);
  assert.equal(calculateBMI(NaN, 175), null);
});

test('getHealthyWeightRangeKg and getDaysRemaining return accurate values', () => {
  const [minKg, maxKg] = getHealthyWeightRangeKg(175);
  assert.equal(minKg, 56.7);
  assert.equal(maxKg, 76.3);

  const ref = new Date('2026-11-15T12:00:00Z');
  assert.equal(getDaysRemaining('2026-11-25', ref), 11);
  assert.equal(getDaysRemaining('2026-11-01', ref), 0);
});

test('classifyBMI maps underweight, healthy, overweight, and unhealthy categories with matching goals', () => {
  const underweight = classifyBMI(17.0, 175);
  assert.equal(underweight.category, 'Underweight');
  assert.equal(underweight.suggestedGoal, 'Weight Gain');
  assert.equal(underweight.statusTone, 'info');

  const healthy = classifyBMI(22.4, 175);
  assert.equal(healthy.category, 'Healthy Weight');
  assert.equal(healthy.suggestedGoal, 'Strength Training');
  assert.equal(healthy.statusTone, 'healthy');

  const overweight = classifyBMI(27.2, 175);
  assert.equal(overweight.category, 'Overweight');
  assert.equal(overweight.suggestedGoal, 'Weight Loss');
  assert.equal(overweight.statusTone, 'caution');

  const unhealthy = classifyBMI(32.0, 175);
  assert.equal(unhealthy.category, 'Unhealthy (Obesity)');
  assert.equal(unhealthy.suggestedGoal, 'Weight Loss');
  assert.equal(unhealthy.statusTone, 'alert');
});

test('getGoalWorkoutPlan tailors conditioning note for higher BMI weight loss', () => {
  const highBmiPlan = getGoalWorkoutPlan('Weight Loss', 32.5);
  assert.match(highBmiPlan.sessions[1].detail, /Low-impact/i);
  const yogaPlan = getGoalWorkoutPlan('Yoga & Mobility', 22.0);
  assert.equal(yogaPlan.sessions.length, 4);
});

test('validateSignupForm validates heightFeet (e.g. 5.7, 5.10), allows optional email, and catches duplicate usernames', () => {
  const validNoEmail = validateSignupForm(
    {
      fullName: 'Rohan Patel',
      username: 'rohan_fit',
      email: '',
      phone: '9876543210',
      address: '42 Maple Avenue, Suite 3',
      age: '26',
      heightFeet: '5.7',
      weightKg: '72',
      gender: 'Male',
      goal: 'Strength Training',
      password: 'password123',
    },
    ['alex_runner']
  );
  assert.deepEqual(validNoEmail, {});

  const validFiveTen = validateSignupForm(
    {
      fullName: 'Rohan Patel',
      username: 'rohan_ten',
      email: '',
      phone: '9876543210',
      address: '42 Maple Avenue, Suite 3',
      age: '26',
      heightFeet: '5.10',
      weightKg: '72',
      gender: 'Male',
      goal: 'Strength Training',
      password: 'password123',
    },
    []
  );
  assert.deepEqual(validFiveTen, {});

  const duplicateAndBadInputs = validateSignupForm(
    {
      fullName: 'A',
      username: 'ALEX_RUNNER',
      email: 'not-an-email',
      phone: '123',
      address: 'abc',
      age: '10',
      heightFeet: '5.15',
      weightKg: '72',
      gender: '',
      goal: '',
      password: '123',
    },
    ['alex_runner']
  );
  assert.ok(duplicateAndBadInputs.fullName);
  assert.ok(duplicateAndBadInputs.username);
  assert.ok(duplicateAndBadInputs.email);
  assert.ok(duplicateAndBadInputs.phone);
  assert.ok(duplicateAndBadInputs.address);
  assert.ok(duplicateAndBadInputs.age);
  assert.ok(duplicateAndBadInputs.heightFeet);
  assert.ok(duplicateAndBadInputs.gender);
  assert.ok(duplicateAndBadInputs.goal);
  assert.ok(duplicateAndBadInputs.password);
});

test('validateContactForm enforces valid contact and message length', () => {
  const invalid = validateContactForm({
    name: 'K',
    contact: 'bad',
    topic: 'General',
    message: 'Hi',
  });
  assert.ok(invalid.name);
  assert.ok(invalid.contact);
  assert.ok(invalid.message);

  const valid = validateContactForm({
    name: 'Maya Lin',
    contact: '+1 555 234 5678',
    topic: 'Weight Loss Coaching',
    message: 'Interested in booking an initial BMI and movement assessment this week.',
  });
  assert.deepEqual(valid, {});
});
