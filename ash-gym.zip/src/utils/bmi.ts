import type { GenderOption, GoalOption } from '../types/gym';

export type BMICategory =
  | 'Underweight'
  | 'Healthy Weight'
  | 'Overweight'
  | 'Unhealthy (Obesity)';

export type BMIStatusTone = 'info' | 'healthy' | 'caution' | 'alert';

export interface BMIAssessment {
  bmi: number;
  category: BMICategory;
  shortLabel: string;
  statusTone: BMIStatusTone;
  whyExplanation: string;
  healthyWeightRangeKg: [number, number];
  suggestedGoal: GoalOption;
  suggestedPlanTitle: string;
  personalizedWorkouts: string[];
  nutritionNote: string;
}

export interface SignupFormValues {
  fullName: string;
  username: string;
  email: string;
  phone: string;
  address: string;
  age: string;
  heightFeet: string;
  weightKg: string;
  gender: GenderOption | '';
  goal: GoalOption | '';
  password: string;
}

export type ValidationErrors<T extends string> = Partial<Record<T, string>>;

/**
 * Converts height in inches to centimeters (rounded to 1 decimal place).
 */
export function inchesToCm(inches: number): number {
  return Math.round(inches * 2.54 * 10) / 10;
}

/**
 * Parses feet.inches notation (e.g. "5.7" -> 5 ft 7 in -> 67 in, "5.10" -> 5 ft 10 in -> 70 in,
 * "6" -> 72 in, "5'7" -> 67 in) into total inches. Returns null when invalid or out of range.
 */
export function parseFeetNotationToInches(raw: string): number | null {
  const trimmed = raw.trim().replace(/"/g, '');
  if (!trimmed) return null;

  // Support either "5.7", "5.10", "5", or "5'7"
  const match = trimmed.match(/^(\d{1,2})(?:[.'’](\d{1,2}))?$/);
  if (!match) return null;

  const feet = Number(match[1]);
  const inchesPart = match[2] !== undefined ? Number(match[2]) : 0;

  if (!Number.isInteger(feet) || !Number.isInteger(inchesPart)) {
    return null;
  }
  if (inchesPart < 0 || inchesPart > 11) {
    return null;
  }

  const totalInches = feet * 12 + inchesPart;
  if (totalInches < 36 || totalInches > 96) {
    return null;
  }

  return totalInches;
}

/**
 * Converts total inches back into ft.in string notation (e.g. 67 -> "5.7", 70 -> "5.10", 72 -> "6.0").
 */
export function inchesToFeetNotation(inches: number): string {
  if (!Number.isFinite(inches) || inches < 36 || inches > 96) {
    return '';
  }
  const rounded = Math.round(inches);
  const feet = Math.floor(rounded / 12);
  const remInches = rounded % 12;
  return `${feet}.${remInches}`;
}

/**
 * Formats total inches as "X ft Y in" for clean display alongside ft.in input.
 */
export function formatInchesToFeetInches(inches: number): string {
  if (!Number.isFinite(inches) || inches < 36 || inches > 96) {
    return '';
  }
  const rounded = Math.round(inches);
  const feet = Math.floor(rounded / 12);
  const remInches = rounded % 12;
  return `${feet} ft ${remInches} in`;
}

/**
 * Calculates BMI from weight (kg) and height (cm), rounded to 1 decimal place.
 */
export function calculateBMI(weightKg: number, heightCm: number): number | null {
  if (!Number.isFinite(weightKg) || !Number.isFinite(heightCm)) {
    return null;
  }
  if (weightKg < 20 || weightKg > 350 || heightCm < 90 || heightCm > 250) {
    return null;
  }
  const heightM = heightCm / 100;
  const raw = weightKg / (heightM * heightM);
  return Math.round(raw * 10) / 10;
}

/**
 * Calculates BMI directly from weight (kg) and height (inches).
 */
export function calculateBMIFromInches(
  weightKg: number,
  heightInches: number
): number | null {
  if (!Number.isFinite(heightInches) || heightInches < 36 || heightInches > 96) {
    return null;
  }
  return calculateBMI(weightKg, inchesToCm(heightInches));
}

/**
 * Calculates BMI directly from weight (kg) and height in ft.in notation (e.g. "5.7").
 */
export function calculateBMIFromFeetNotation(
  weightKg: number,
  heightFeet: string
): number | null {
  const inches = parseFeetNotationToInches(heightFeet);
  if (inches === null) return null;
  return calculateBMIFromInches(weightKg, inches);
}

/**
 * Computes the healthy weight range (BMI 18.5 to 24.9) in kg for a given height in cm.
 */
export function getHealthyWeightRangeKg(heightCm: number): [number, number] {
  const heightM = heightCm / 100;
  const minKg = Math.round(18.5 * heightM * heightM * 10) / 10;
  const maxKg = Math.round(24.9 * heightM * heightM * 10) / 10;
  return [minKg, maxKg];
}

/**
 * Computes remaining membership days from an ISO date string (YYYY-MM-DD).
 */
export function getDaysRemaining(
  expiryIsoDate: string,
  referenceDate: Date = new Date()
): number {
  const target = new Date(`${expiryIsoDate}T23:59:59`);
  if (Number.isNaN(target.getTime())) return 0;
  const diffMs = target.getTime() - referenceDate.getTime();
  return Math.max(0, Math.ceil(diffMs / (1000 * 60 * 60 * 24)));
}

/**
 * Classifies BMI and generates a clear explanation + personalized workout goal suggestion.
 */
export function classifyBMI(bmi: number, heightCm = 170): BMIAssessment {
  const healthyWeightRangeKg = getHealthyWeightRangeKg(
    Number.isFinite(heightCm) && heightCm >= 90 && heightCm <= 250 ? heightCm : 170
  );

  if (bmi < 18.5) {
    return {
      bmi,
      category: 'Underweight',
      shortLabel: 'Underweight',
      statusTone: 'info',
      whyExplanation:
        'A BMI below 18.5 shows your body weight is lower than the typical healthy range for your height. Building lean muscle mass strengthens your bones, posture, and daily energy.',
      healthyWeightRangeKg,
      suggestedGoal: 'Weight Gain',
      suggestedPlanTitle: 'Lean Mass & Progressive Strength (4 Days/Week)',
      personalizedWorkouts: [
        '45-min compound barbell & dumbbell sessions (squat, press, row)',
        'Moderate rep ranges (6–10 reps) with controlled tempo for muscle growth',
        'Limit exhausting cardio to 2 short 15-min recovery walks weekly',
        '10-min post-session mobility work to keep joints supple',
      ],
      nutritionNote:
        'Aim for a steady 300–450 kcal daily surplus with protein in every meal.',
    };
  }

  if (bmi < 25) {
    return {
      bmi,
      category: 'Healthy Weight',
      shortLabel: 'Healthy',
      statusTone: 'healthy',
      whyExplanation:
        'A BMI between 18.5 and 24.9 sits right inside the standard healthy range for your height. Your baseline supports either building athletic strength or deepening mobility.',
      healthyWeightRangeKg,
      suggestedGoal: 'Strength Training',
      suggestedPlanTitle: 'Balanced Strength & Athletic Conditioning (4 Days/Week)',
      personalizedWorkouts: [
        '3 days of structured full-body strength (deadlift, overhead press, pull-ups)',
        '1 day of guided Yoga & thoracic/hip mobility for posture and recovery',
        '20-min zone-2 cardio conditioning twice weekly for heart stamina',
        'Track progressive overload every two weeks',
      ],
      nutritionNote:
        'Maintain daily maintenance calories with balanced protein (1.6g/kg body weight).',
    };
  }

  if (bmi < 30) {
    return {
      bmi,
      category: 'Overweight',
      shortLabel: 'Overweight',
      statusTone: 'caution',
      whyExplanation:
        'A BMI between 25.0 and 29.9 indicates extra body weight relative to your height, which can add load to knees and lower back. Combining resistance training with steady conditioning improves body composition while protecting muscle.',
      healthyWeightRangeKg,
      suggestedGoal: 'Weight Loss',
      suggestedPlanTitle: 'Metabolic Strength & Steady Fat Loss (4 Days/Week)',
      personalizedWorkouts: [
        '3 days of circuit resistance training to preserve lean muscle while burning energy',
        '2 days of low-impact rowing, incline walking, or cycling (30–40 min)',
        'Core stability & hip-hinge coaching to protect your lower back',
        'Daily 8,000-step movement target outside gym hours',
      ],
      nutritionNote:
        'Target a gentle 350–500 kcal daily deficit focused on whole foods and high fiber.',
    };
  }

  return {
    bmi,
    category: 'Unhealthy (Obesity)',
    shortLabel: 'Unhealthy',
    statusTone: 'alert',
    whyExplanation:
      'A BMI of 30.0 or higher places extra strain on your cardiovascular system and weight-bearing joints. Starting with low-impact strength and guided pacing builds stamina safely without joint overload.',
    healthyWeightRangeKg,
    suggestedGoal: 'Weight Loss',
    suggestedPlanTitle: 'Joint-Friendly Conditioning & Guided Fat Loss (3–4 Days/Week)',
    personalizedWorkouts: [
      '3 coach-guided low-impact strength sessions (kettlebells, sleds, machines)',
      'Joint-safe cardio on stationary bike, rower, or incline treadmill (20–30 min)',
      '1 gentle Yoga & breathing recovery session to support sleep and stress control',
      'Weekly check-ins to adjust intensity smoothly as stamina rises',
    ],
    nutritionNote:
      'Prioritize steady protein, hydration, and gradual 400–500 kcal reduction—never crash dieting.',
  };
}

/**
 * Generates a weekly workout split tailored to a member's chosen Goal and current BMI.
 */
export function getGoalWorkoutPlan(goal: GoalOption, bmi: number | null): {
  headline: string;
  frequency: string;
  sessions: { day: string; focus: string; detail: string }[];
} {
  if (goal === 'Weight Gain') {
    return {
      headline: 'Hypertrophy & Strength Surplus Split',
      frequency: '4 Training Days · 55 Min Each',
      sessions: [
        { day: 'Monday', focus: 'Upper Body Push & Pull', detail: 'Incline dumbbell press, chest-supported row, lateral raises' },
        { day: 'Tuesday', focus: 'Lower Body Foundation', detail: 'Goblet or barbell squat, Romanian deadlift, calf raises' },
        { day: 'Thursday', focus: 'Full-Body Compound', detail: 'Overhead press, weighted pull-ups, split squats' },
        { day: 'Saturday', focus: 'Arms, Core & Mobility', detail: 'Controlled curls, dips, Pallof press, 15-min stretch' },
      ],
    };
  }

  if (goal === 'Weight Loss') {
    const lowImpactNote =
      bmi !== null && bmi >= 30
        ? 'Low-impact ergometer intervals & sled pushes'
        : 'Kettlebell complexes & rowing intervals';
    return {
      headline: 'Metabolic Resistance & Fat Loss Split',
      frequency: '4 Training Days · 45–50 Min Each',
      sessions: [
        { day: 'Monday', focus: 'Full-Body Strength Circuit', detail: 'Squats, push-ups, rows, 45s work / 20s rest' },
        { day: 'Wednesday', focus: 'Cardio Conditioning', detail: lowImpactNote },
        { day: 'Friday', focus: 'Posterior Chain & Core', detail: 'Hip hinge drills, step-ups, farmer carries, planks' },
        { day: 'Saturday', focus: 'Active Recovery Walk & Mobility', detail: '35-min incline walk + 15-min hip & spine flow' },
      ],
    };
  }

  if (goal === 'Yoga & Mobility') {
    return {
      headline: 'Mobility, Balance & Breathwork Split',
      frequency: '4 Guided Sessions · 50 Min Each',
      sessions: [
        { day: 'Monday', focus: 'Spine & Shoulder Opening', detail: 'Cat-cow, thoracic rotations, downward dog transitions' },
        { day: 'Wednesday', focus: 'Vinyasa Flow & Core', detail: 'Sun salutations, warrior sequences, controlled balance holds' },
        { day: 'Friday', focus: 'Hip Mobility & Stability', detail: '90/90 transitions, pigeon variations, single-leg balance' },
        { day: 'Sunday', focus: 'Restorative Breathwork', detail: 'Box breathing, deep hamstring release, guided relaxation' },
      ],
    };
  }

  return {
    headline: 'Progressive Strength & Conditioning Split',
    frequency: '4 Training Days · 60 Min Each',
    sessions: [
      { day: 'Monday', focus: 'Squat & Push Strength', detail: 'Back squat 4x5, bench press 4x6, core bracing' },
      { day: 'Wednesday', focus: 'Hinge & Pull Strength', detail: 'Deadlift 3x5, pull-ups 4x8, face pulls' },
      { day: 'Friday', focus: 'Power & Conditioning', detail: 'Overhead press, kettlebell swings, turf sled sprints' },
      { day: 'Saturday', focus: 'Mobility & Joint Prehab', detail: 'Rotator cuff drills, ankle dorsiflexion, yoga flow' },
    ],
  };
}

export function validateSignupForm(
  values: SignupFormValues,
  existingUsernames: string[] = []
): ValidationErrors<keyof SignupFormValues> {
  const errors: ValidationErrors<keyof SignupFormValues> = {};

  if (!values.fullName.trim() || values.fullName.trim().length < 2) {
    errors.fullName = 'Please enter your full name.';
  }

  const usernameClean = values.username.trim().toLowerCase();
  if (!usernameClean || !/^[a-z0-9_]{3,24}$/.test(usernameClean)) {
    errors.username = 'Username must be 3–24 characters (letters, numbers, or underscores).';
  } else if (existingUsernames.map((u) => u.toLowerCase()).includes(usernameClean)) {
    errors.username = 'That username is already registered. Choose another or log in.';
  }

  if (values.email.trim()) {
    const emailOk = /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(values.email.trim());
    if (!emailOk) {
      errors.email = 'Enter a valid email address or leave this field blank.';
    }
  }

  const digits = values.phone.replace(/\D/g, '');
  if (digits.length < 7 || digits.length > 15) {
    errors.phone = 'Enter a valid contact phone number (7–15 digits).';
  }

  if (!values.address.trim() || values.address.trim().length < 5) {
    errors.address = 'Please enter your street or neighborhood address.';
  }

  const age = Number(values.age);
  if (!Number.isFinite(age) || age < 13 || age > 100) {
    errors.age = 'Age must be between 13 and 100.';
  }

  const parsedInches = parseFeetNotationToInches(values.heightFeet);
  if (parsedInches === null) {
    errors.heightFeet =
      'Enter height in ft.in format between 3.0 and 8.0 (e.g. 5.7 for 5 ft 7 in; inches 0–11).';
  }

  const weightKg = Number(values.weightKg);
  if (!Number.isFinite(weightKg) || weightKg < 20 || weightKg > 350) {
    errors.weightKg = 'Weight must be between 20 kg and 350 kg.';
  }

  if (!values.gender) {
    errors.gender = 'Please select your gender.';
  }

  if (!values.goal) {
    errors.goal = 'Please select your primary training goal.';
  }

  if (!values.password || values.password.length < 6) {
    errors.password = 'Password must be at least 6 characters.';
  }

  return errors;
}

export interface ContactFormValues {
  name: string;
  contact: string;
  topic: string;
  message: string;
}

export function validateContactForm(
  values: ContactFormValues
): ValidationErrors<keyof ContactFormValues> {
  const errors: ValidationErrors<keyof ContactFormValues> = {};
  if (!values.name.trim() || values.name.trim().length < 2) {
    errors.name = 'Please enter your name.';
  }
  const contact = values.contact.trim();
  const isEmail = /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(contact);
  const isPhone = contact.replace(/\D/g, '').length >= 7;
  if (!contact || (!isEmail && !isPhone)) {
    errors.contact = 'Enter a valid phone number or email address.';
  }
  if (!values.message.trim() || values.message.trim().length < 10) {
    errors.message = 'Please share a brief note (at least 10 characters).';
  }
  return errors;
}
